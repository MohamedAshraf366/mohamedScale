-- Create categories table to store custom category metadata
CREATE TABLE IF NOT EXISTS public.categories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  icon TEXT NOT NULL DEFAULT 'Package',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "All authenticated users can view categories"
ON public.categories
FOR SELECT
USING (true);

CREATE POLICY "All authenticated users can insert categories"
ON public.categories
FOR INSERT
WITH CHECK (true);

CREATE POLICY "All authenticated users can update categories"
ON public.categories
FOR UPDATE
USING (true);

CREATE POLICY "Admins can delete categories"
ON public.categories
FOR DELETE
USING (check_user_role(auth.uid(), 'admin'::app_role));

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_categories_updated_at
BEFORE UPDATE ON public.categories
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();