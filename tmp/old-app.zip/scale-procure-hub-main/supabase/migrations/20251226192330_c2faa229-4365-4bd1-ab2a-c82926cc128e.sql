-- Create opportunity_materials table for storing requested materials per deal
CREATE TABLE public.opportunity_materials (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  opportunity_id UUID NOT NULL REFERENCES public.opportunities(id) ON DELETE CASCADE,
  material_name TEXT NOT NULL,
  quantity NUMERIC,
  expected_delivery_date DATE,
  pricing_type TEXT NOT NULL DEFAULT 'quantity_based' CHECK (pricing_type IN ('quantity_based', 'soft_quotation')),
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.opportunity_materials ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "All authenticated users can view opportunity materials"
ON public.opportunity_materials
FOR SELECT
USING (true);

CREATE POLICY "Admins and procurement can insert opportunity materials"
ON public.opportunity_materials
FOR INSERT
WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can update opportunity materials"
ON public.opportunity_materials
FOR UPDATE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can delete opportunity materials"
ON public.opportunity_materials
FOR DELETE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

-- Add index for faster lookups
CREATE INDEX idx_opportunity_materials_opportunity_id ON public.opportunity_materials(opportunity_id);