-- Add missing columns to communication_log table
ALTER TABLE communication_log
ADD COLUMN IF NOT EXISTS category text,
ADD COLUMN IF NOT EXISTS communication_channels text,
ADD COLUMN IF NOT EXISTS summary text,
ADD COLUMN IF NOT EXISTS quotation_required boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS assigned_to uuid REFERENCES auth.users(id);