-- Add workflow_step column to strategic_blockers table
ALTER TABLE public.strategic_blockers 
ADD COLUMN workflow_step text;