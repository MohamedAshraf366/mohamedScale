-- Add target_price and cycle_status columns to material_unlock_cycles
ALTER TABLE public.material_unlock_cycles 
ADD COLUMN IF NOT EXISTS target_price numeric,
ADD COLUMN IF NOT EXISTS cycle_status text DEFAULT 'collecting_quotes' 
  CHECK (cycle_status IN ('collecting_quotes', 'filtering', 'negotiating', 'agreement_signed'));

-- Create material_unlock_suppliers table for supplier participation in unlock cycles
CREATE TABLE IF NOT EXISTS public.material_unlock_suppliers (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  cycle_id uuid NOT NULL REFERENCES public.material_unlock_cycles(id) ON DELETE CASCADE,
  supplier_id uuid NOT NULL REFERENCES public.suppliers(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'collecting_quotes' 
    CHECK (status IN ('collecting_quotes', 'filtering', 'negotiating', 'agreement_signed', 'rejected')),
  quoted_price numeric,
  final_price numeric,
  delivery_price numeric,
  total_price numeric,
  notes text,
  quoted_at timestamp with time zone,
  agreed_at timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(cycle_id, supplier_id)
);

-- Enable RLS on material_unlock_suppliers
ALTER TABLE public.material_unlock_suppliers ENABLE ROW LEVEL SECURITY;

-- RLS policies for material_unlock_suppliers
CREATE POLICY "All authenticated users can view material unlock suppliers" 
  ON public.material_unlock_suppliers FOR SELECT 
  USING (true);

CREATE POLICY "Admins and procurement can insert material unlock suppliers" 
  ON public.material_unlock_suppliers FOR INSERT 
  WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can update material unlock suppliers" 
  ON public.material_unlock_suppliers FOR UPDATE 
  USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can delete material unlock suppliers" 
  ON public.material_unlock_suppliers FOR DELETE 
  USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_material_unlock_suppliers_cycle_id ON public.material_unlock_suppliers(cycle_id);
CREATE INDEX IF NOT EXISTS idx_material_unlock_suppliers_supplier_id ON public.material_unlock_suppliers(supplier_id);
CREATE INDEX IF NOT EXISTS idx_material_unlock_suppliers_status ON public.material_unlock_suppliers(status);

-- Add updated_at trigger
CREATE TRIGGER update_material_unlock_suppliers_updated_at
  BEFORE UPDATE ON public.material_unlock_suppliers
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();