-- Create approval status enum for renegotiations
CREATE TYPE public.renegotiation_approval_status AS ENUM (
  'pending_supply_head',
  'pending_management', 
  'approved',
  'rejected',
  'active'
);

-- Create material_renegotiations table
CREATE TABLE public.material_renegotiations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  
  -- Link to sales objection/communication
  objection_id UUID REFERENCES public.communication_log(id) ON DELETE SET NULL,
  
  -- Material being renegotiated
  material_id UUID NOT NULL REFERENCES public.materials(id) ON DELETE CASCADE,
  
  -- Supplier for renegotiation
  supplier_id UUID REFERENCES public.suppliers(id) ON DELETE SET NULL,
  
  -- Price data
  current_price NUMERIC,
  sales_suggested_price NUMERIC,
  supply_head_target NUMERIC,
  management_approved_target NUMERIC,
  
  -- Approval workflow
  approval_status public.renegotiation_approval_status NOT NULL DEFAULT 'pending_supply_head',
  
  -- Scheduling
  scheduled_date DATE,
  
  -- Justification and notes
  supply_head_notes TEXT,
  management_notes TEXT,
  rejection_reason TEXT,
  
  -- Tracking
  requested_by UUID,
  supply_head_reviewed_by UUID,
  supply_head_reviewed_at TIMESTAMPTZ,
  management_reviewed_by UUID,
  management_reviewed_at TIMESTAMPTZ,
  
  -- Renegotiation outcome
  final_agreed_price NUMERIC,
  renegotiation_status TEXT DEFAULT 'pending',
  completed_at TIMESTAMPTZ,
  
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.material_renegotiations ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "All authenticated users can view renegotiations"
ON public.material_renegotiations
FOR SELECT
USING (true);

CREATE POLICY "Admins and procurement can insert renegotiations"
ON public.material_renegotiations
FOR INSERT
WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can update renegotiations"
ON public.material_renegotiations
FOR UPDATE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins can delete renegotiations"
ON public.material_renegotiations
FOR DELETE
USING (check_user_role(auth.uid(), 'admin'::app_role));

-- Create indexes for common queries
CREATE INDEX idx_material_renegotiations_status ON public.material_renegotiations(approval_status);
CREATE INDEX idx_material_renegotiations_material ON public.material_renegotiations(material_id);
CREATE INDEX idx_material_renegotiations_supplier ON public.material_renegotiations(supplier_id);
CREATE INDEX idx_material_renegotiations_scheduled ON public.material_renegotiations(scheduled_date);

-- Trigger for updated_at
CREATE TRIGGER update_material_renegotiations_updated_at
BEFORE UPDATE ON public.material_renegotiations
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Add comments
COMMENT ON TABLE public.material_renegotiations IS 'Tracks material price renegotiations with multi-tier approval workflow';
COMMENT ON COLUMN public.material_renegotiations.objection_id IS 'Link to sales communication/objection that triggered renegotiation';
COMMENT ON COLUMN public.material_renegotiations.sales_suggested_price IS 'Price suggested by sales team based on client feedback';
COMMENT ON COLUMN public.material_renegotiations.supply_head_target IS 'Target price proposed by Supply Head';
COMMENT ON COLUMN public.material_renegotiations.management_approved_target IS 'Final target approved by management';