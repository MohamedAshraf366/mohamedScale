-- Add category_id column to communication_material_needs
ALTER TABLE public.communication_material_needs
ADD COLUMN category_id uuid REFERENCES public.categories(id) ON DELETE SET NULL;

-- Create index for performance
CREATE INDEX idx_communication_material_needs_category_id ON public.communication_material_needs(category_id);

-- Note: We're keeping category_name for now as a legacy fallback, but category_id will be the source of truth going forward