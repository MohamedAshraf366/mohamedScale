-- Add email column to client_contacts table
ALTER TABLE public.client_contacts 
ADD COLUMN email text;