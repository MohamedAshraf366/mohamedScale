-- Update communication_status enum to only have Open and Closed
-- First, update any 'Follow-up' records to 'Open'
UPDATE communication_log SET status = 'Open' WHERE status = 'Follow-up';

-- Drop the default temporarily
ALTER TABLE communication_log ALTER COLUMN status DROP DEFAULT;

-- Rename the old enum type
ALTER TYPE communication_status RENAME TO communication_status_old;

-- Create new enum with only Open and Closed
CREATE TYPE communication_status AS ENUM ('Open', 'Closed');

-- Update the column to use the new type
ALTER TABLE communication_log 
  ALTER COLUMN status TYPE communication_status 
  USING status::text::communication_status;

-- Re-add the default
ALTER TABLE communication_log 
  ALTER COLUMN status SET DEFAULT 'Open'::communication_status;

-- Drop the old type
DROP TYPE communication_status_old;