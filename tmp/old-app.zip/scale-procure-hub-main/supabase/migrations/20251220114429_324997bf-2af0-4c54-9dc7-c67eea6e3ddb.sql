-- Add target_price column to materials table
ALTER TABLE public.materials ADD COLUMN IF NOT EXISTS target_price numeric;

-- Create zones table for coverage tracking
CREATE TABLE IF NOT EXISTS public.zones (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL UNIQUE,
  city text,
  region text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on zones
ALTER TABLE public.zones ENABLE ROW LEVEL SECURITY;

-- RLS policies for zones
CREATE POLICY "All authenticated users can view zones" 
  ON public.zones FOR SELECT 
  USING (true);

CREATE POLICY "Admins and procurement can insert zones" 
  ON public.zones FOR INSERT 
  WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can update zones" 
  ON public.zones FOR UPDATE 
  USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins can delete zones" 
  ON public.zones FOR DELETE 
  USING (check_user_role(auth.uid(), 'admin'::app_role));

-- Create material_price_versions table for confirmed price history
CREATE TABLE IF NOT EXISTS public.material_price_versions (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  material_id uuid NOT NULL REFERENCES public.materials(id) ON DELETE CASCADE,
  supplier_id uuid NOT NULL REFERENCES public.suppliers(id) ON DELETE CASCADE,
  unit_price numeric,
  delivery_price numeric,
  total_price numeric,
  valid_from date NOT NULL DEFAULT CURRENT_DATE,
  valid_until date,
  confirmation_status text NOT NULL DEFAULT 'pending' CHECK (confirmation_status IN ('pending', 'confirmed', 'expired', 'rejected')),
  confirmed_by uuid,
  confirmed_at timestamp with time zone,
  notes text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on material_price_versions
ALTER TABLE public.material_price_versions ENABLE ROW LEVEL SECURITY;

-- RLS policies for material_price_versions
CREATE POLICY "All authenticated users can view material price versions" 
  ON public.material_price_versions FOR SELECT 
  USING (true);

CREATE POLICY "Admins and procurement can insert material price versions" 
  ON public.material_price_versions FOR INSERT 
  WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can update material price versions" 
  ON public.material_price_versions FOR UPDATE 
  USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can delete material price versions" 
  ON public.material_price_versions FOR DELETE 
  USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

-- Create material_coverage table for zone coverage per material
CREATE TABLE IF NOT EXISTS public.material_coverage (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  material_id uuid NOT NULL REFERENCES public.materials(id) ON DELETE CASCADE,
  zone_id uuid NOT NULL REFERENCES public.zones(id) ON DELETE CASCADE,
  supplier_id uuid REFERENCES public.suppliers(id) ON DELETE SET NULL,
  is_covered boolean NOT NULL DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(material_id, zone_id, supplier_id)
);

-- Enable RLS on material_coverage
ALTER TABLE public.material_coverage ENABLE ROW LEVEL SECURITY;

-- RLS policies for material_coverage
CREATE POLICY "All authenticated users can view material coverage" 
  ON public.material_coverage FOR SELECT 
  USING (true);

CREATE POLICY "Admins and procurement can insert material coverage" 
  ON public.material_coverage FOR INSERT 
  WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can update material coverage" 
  ON public.material_coverage FOR UPDATE 
  USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can delete material coverage" 
  ON public.material_coverage FOR DELETE 
  USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

-- Add status column to supplier_materials if not exists
ALTER TABLE public.supplier_materials ADD COLUMN IF NOT EXISTS status text DEFAULT 'active' CHECK (status IN ('active', 'selected', 'backup', 'inactive'));

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_material_price_versions_material_id ON public.material_price_versions(material_id);
CREATE INDEX IF NOT EXISTS idx_material_price_versions_supplier_id ON public.material_price_versions(supplier_id);
CREATE INDEX IF NOT EXISTS idx_material_price_versions_confirmation_status ON public.material_price_versions(confirmation_status);
CREATE INDEX IF NOT EXISTS idx_material_price_versions_valid_from ON public.material_price_versions(valid_from);
CREATE INDEX IF NOT EXISTS idx_material_coverage_material_id ON public.material_coverage(material_id);
CREATE INDEX IF NOT EXISTS idx_material_coverage_zone_id ON public.material_coverage(zone_id);

-- Add updated_at triggers
CREATE TRIGGER update_zones_updated_at
  BEFORE UPDATE ON public.zones
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_material_price_versions_updated_at
  BEFORE UPDATE ON public.material_price_versions
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_material_coverage_updated_at
  BEFORE UPDATE ON public.material_coverage
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();