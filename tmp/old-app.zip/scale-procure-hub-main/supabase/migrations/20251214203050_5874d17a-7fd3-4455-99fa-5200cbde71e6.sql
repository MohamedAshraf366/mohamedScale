-- Add tags column to general_tasks table
ALTER TABLE public.general_tasks 
ADD COLUMN tags text[] DEFAULT '{}'::text[];

-- Add tags column to follow_up_history table
ALTER TABLE public.follow_up_history 
ADD COLUMN tags text[] DEFAULT '{}'::text[];