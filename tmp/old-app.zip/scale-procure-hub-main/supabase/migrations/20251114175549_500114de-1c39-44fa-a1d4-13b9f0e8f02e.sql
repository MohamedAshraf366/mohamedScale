-- Add new price columns to material_alt_suppliers table
ALTER TABLE material_alt_suppliers 
ADD COLUMN manufacturer_price numeric,
ADD COLUMN delivery_price numeric;

-- Update existing records to set manufacturer_price from unit_price
UPDATE material_alt_suppliers 
SET manufacturer_price = unit_price,
    delivery_price = 0
WHERE manufacturer_price IS NULL;