
-- Add deal closure fields to communication_log
ALTER TABLE public.communication_log
ADD COLUMN IF NOT EXISTS deal_closed_at timestamp with time zone,
ADD COLUMN IF NOT EXISTS deal_started_at timestamp with time zone,
ADD COLUMN IF NOT EXISTS deal_duration_days integer,
ADD COLUMN IF NOT EXISTS deal_value_total numeric,
ADD COLUMN IF NOT EXISTS deal_project_name text,
ADD COLUMN IF NOT EXISTS deal_city text,
ADD COLUMN IF NOT EXISTS deal_district text,
ADD COLUMN IF NOT EXISTS deal_location_notes text,
ADD COLUMN IF NOT EXISTS deal_supplier_id uuid REFERENCES public.suppliers(id),
ADD COLUMN IF NOT EXISTS deal_supplier_rating integer,
ADD COLUMN IF NOT EXISTS deal_supplier_feedback text,
ADD COLUMN IF NOT EXISTS deal_delivery_type text,
ADD COLUMN IF NOT EXISTS deal_delivery_rating integer,
ADD COLUMN IF NOT EXISTS deal_delivery_feedback text,
ADD COLUMN IF NOT EXISTS client_price_satisfaction integer,
ADD COLUMN IF NOT EXISTS client_delivery_satisfaction integer,
ADD COLUMN IF NOT EXISTS client_quality_satisfaction integer,
ADD COLUMN IF NOT EXISTS client_overall_satisfaction integer,
ADD COLUMN IF NOT EXISTS client_liked text,
ADD COLUMN IF NOT EXISTS client_improvements text,
ADD COLUMN IF NOT EXISTS client_retention_ideas text;

-- Create table for closed deal items (ordered materials)
CREATE TABLE IF NOT EXISTS public.closed_deal_items (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  communication_id uuid NOT NULL REFERENCES public.communication_log(id) ON DELETE CASCADE,
  material_id uuid REFERENCES public.materials(id),
  quantity numeric,
  unit text,
  final_unit_price numeric,
  line_total numeric,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.closed_deal_items ENABLE ROW LEVEL SECURITY;

-- RLS policies for closed_deal_items
CREATE POLICY "All authenticated users can view closed deal items"
ON public.closed_deal_items FOR SELECT
USING (true);

CREATE POLICY "Admins and procurement can insert closed deal items"
ON public.closed_deal_items FOR INSERT
WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can update closed deal items"
ON public.closed_deal_items FOR UPDATE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can delete closed deal items"
ON public.closed_deal_items FOR DELETE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));
