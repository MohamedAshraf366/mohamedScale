-- Add "In Follow-up" to the communication_status enum
ALTER TYPE public.communication_status ADD VALUE IF NOT EXISTS 'In Follow-up';