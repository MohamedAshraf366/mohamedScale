-- First drop the existing constraint
ALTER TABLE public.opportunity_materials 
DROP CONSTRAINT IF EXISTS opportunity_materials_pricing_type_check;

-- Update existing records to use new values
UPDATE public.opportunity_materials 
SET pricing_type = 'Soft' 
WHERE pricing_type IN ('soft_quotation', 'Soft Quotation', 'soft');

UPDATE public.opportunity_materials 
SET pricing_type = 'Quantity based' 
WHERE pricing_type IN ('firm_quotation', 'Firm Quotation', 'budget_estimate', 'Budget Estimate', 'quantity_based');

-- Now add the constraint with new values only
ALTER TABLE public.opportunity_materials 
ADD CONSTRAINT opportunity_materials_pricing_type_check 
CHECK (pricing_type IN ('Soft', 'Quantity based'));