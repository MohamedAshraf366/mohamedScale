-- Add closure audit columns to operations_orders
ALTER TABLE public.operations_orders 
ADD COLUMN IF NOT EXISTS closed_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS closed_by_name TEXT;