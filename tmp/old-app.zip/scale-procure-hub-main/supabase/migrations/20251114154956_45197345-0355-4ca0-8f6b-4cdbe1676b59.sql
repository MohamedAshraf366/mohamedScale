-- Add deal_completed field to communication_log table
ALTER TABLE communication_log 
ADD COLUMN IF NOT EXISTS deal_completed BOOLEAN DEFAULT FALSE;