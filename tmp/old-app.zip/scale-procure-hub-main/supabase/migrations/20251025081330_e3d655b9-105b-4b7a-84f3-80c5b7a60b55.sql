-- Drop the security definer view and recreate without it
DROP VIEW IF EXISTS public.supplier_stats;

-- Create a regular view without SECURITY DEFINER
CREATE VIEW public.supplier_stats AS
SELECT 
  s.id,
  s.name,
  COUNT(DISTINCT cl.id) as total_communications,
  COUNT(DISTINCT CASE WHEN cl.quotation_required = true THEN cl.id END) as total_quotations,
  COALESCE(SUM(CASE WHEN cl.quotation_required = true THEN cl.quantity * cl.unit_price END), 0) as total_order_value
FROM public.suppliers s
LEFT JOIN public.communication_log cl ON cl.assigned_to = s.name OR cl.company_name = s.name
GROUP BY s.id, s.name;

-- Enable RLS on the view
ALTER VIEW public.supplier_stats SET (security_invoker = true);

-- Grant access to the view
GRANT SELECT ON public.supplier_stats TO authenticated;