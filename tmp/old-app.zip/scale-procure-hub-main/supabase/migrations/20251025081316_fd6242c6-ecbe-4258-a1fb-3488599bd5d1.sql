-- Add new columns to suppliers table
ALTER TABLE public.suppliers ADD COLUMN IF NOT EXISTS secondary_phone text;
ALTER TABLE public.suppliers ADD COLUMN IF NOT EXISTS location text;

-- Add pricing column to material_alt_suppliers to track supplier-specific pricing
ALTER TABLE public.material_alt_suppliers ADD COLUMN IF NOT EXISTS unit_price numeric;

-- Create a view to get supplier statistics including total orders
CREATE OR REPLACE VIEW public.supplier_stats AS
SELECT 
  s.id,
  s.name,
  COUNT(DISTINCT cl.id) as total_communications,
  COUNT(DISTINCT CASE WHEN cl.quotation_required = true THEN cl.id END) as total_quotations,
  COALESCE(SUM(CASE WHEN cl.quotation_required = true THEN cl.quantity * cl.unit_price END), 0) as total_order_value
FROM public.suppliers s
LEFT JOIN public.communication_log cl ON cl.assigned_to = s.name OR cl.company_name = s.name
GROUP BY s.id, s.name;

-- Grant access to the view
GRANT SELECT ON public.supplier_stats TO authenticated;