-- Add category column to communication_material_needs table
ALTER TABLE public.communication_material_needs 
ADD COLUMN category_name text;

-- Make material_id nullable since we're now using category_name
ALTER TABLE public.communication_material_needs 
ALTER COLUMN material_id DROP NOT NULL;