-- Add project_id column to follow_up_history table
ALTER TABLE public.follow_up_history
ADD COLUMN project_id UUID REFERENCES public.projects(id) ON DELETE SET NULL;

-- Add index for faster lookups
CREATE INDEX idx_follow_up_history_project_id ON public.follow_up_history(project_id);