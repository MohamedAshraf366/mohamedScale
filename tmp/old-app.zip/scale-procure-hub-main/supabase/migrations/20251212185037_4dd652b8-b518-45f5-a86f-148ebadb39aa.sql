-- Create storage bucket for supplier quotations
INSERT INTO storage.buckets (id, name, public)
VALUES ('supplier-quotations', 'supplier-quotations', true);

-- Create policies for supplier quotations bucket
CREATE POLICY "Authenticated users can view supplier quotations"
ON storage.objects FOR SELECT
USING (bucket_id = 'supplier-quotations');

CREATE POLICY "Admins and procurement can upload supplier quotations"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'supplier-quotations' 
  AND (
    public.check_user_role(auth.uid(), 'admin'::public.app_role) 
    OR public.check_user_role(auth.uid(), 'procurement_officer'::public.app_role)
  )
);

CREATE POLICY "Admins and procurement can update supplier quotations"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'supplier-quotations' 
  AND (
    public.check_user_role(auth.uid(), 'admin'::public.app_role) 
    OR public.check_user_role(auth.uid(), 'procurement_officer'::public.app_role)
  )
);

CREATE POLICY "Admins and procurement can delete supplier quotations"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'supplier-quotations' 
  AND (
    public.check_user_role(auth.uid(), 'admin'::public.app_role) 
    OR public.check_user_role(auth.uid(), 'procurement_officer'::public.app_role)
  )
);

-- Add quotation_url column to suppliers table
ALTER TABLE public.suppliers ADD COLUMN quotation_url text;