-- Create material_unlock_cycles table
CREATE TABLE public.material_unlock_cycles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  material_id uuid REFERENCES public.materials(id) ON DELETE CASCADE NOT NULL,
  unlock_status text NOT NULL DEFAULT 'pending' CHECK (unlock_status IN ('pending', 'in_progress', 'completed', 'cancelled')),
  initiated_by uuid,
  initiated_at timestamp with time zone DEFAULT now(),
  completed_at timestamp with time zone,
  notes text,
  is_renegotiation boolean DEFAULT false,
  renegotiation_status text CHECK (renegotiation_status IN ('not_started', 'in_progress', 'completed', 'cancelled')),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Create material_validity_tracker table
CREATE TABLE public.material_validity_tracker (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  material_id uuid REFERENCES public.materials(id) ON DELETE CASCADE NOT NULL,
  supplier_id uuid REFERENCES public.suppliers(id) ON DELETE CASCADE,
  price_valid_from date NOT NULL DEFAULT CURRENT_DATE,
  price_valid_until date NOT NULL,
  current_price numeric,
  is_active boolean DEFAULT true,
  notification_sent boolean DEFAULT false,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Create supplier_materials table for performance tracking
CREATE TABLE public.supplier_materials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  supplier_id uuid REFERENCES public.suppliers(id) ON DELETE CASCADE NOT NULL,
  material_id uuid REFERENCES public.materials(id) ON DELETE CASCADE NOT NULL,
  performance_rating numeric CHECK (performance_rating >= 0 AND performance_rating <= 5),
  delivery_reliability numeric CHECK (delivery_reliability >= 0 AND delivery_reliability <= 100),
  quality_score numeric CHECK (quality_score >= 0 AND quality_score <= 5),
  total_orders integer DEFAULT 0,
  last_order_date date,
  notes text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(supplier_id, material_id)
);

-- Enable RLS on all tables
ALTER TABLE public.material_unlock_cycles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.material_validity_tracker ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.supplier_materials ENABLE ROW LEVEL SECURITY;

-- RLS policies for material_unlock_cycles
CREATE POLICY "All authenticated users can view unlock cycles"
ON public.material_unlock_cycles FOR SELECT
USING (true);

CREATE POLICY "Admins and procurement can insert unlock cycles"
ON public.material_unlock_cycles FOR INSERT
WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can update unlock cycles"
ON public.material_unlock_cycles FOR UPDATE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can delete unlock cycles"
ON public.material_unlock_cycles FOR DELETE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

-- RLS policies for material_validity_tracker
CREATE POLICY "All authenticated users can view validity tracker"
ON public.material_validity_tracker FOR SELECT
USING (true);

CREATE POLICY "Admins and procurement can insert validity tracker"
ON public.material_validity_tracker FOR INSERT
WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can update validity tracker"
ON public.material_validity_tracker FOR UPDATE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can delete validity tracker"
ON public.material_validity_tracker FOR DELETE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

-- RLS policies for supplier_materials
CREATE POLICY "All authenticated users can view supplier materials"
ON public.supplier_materials FOR SELECT
USING (true);

CREATE POLICY "Admins and procurement can insert supplier materials"
ON public.supplier_materials FOR INSERT
WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can update supplier materials"
ON public.supplier_materials FOR UPDATE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can delete supplier materials"
ON public.supplier_materials FOR DELETE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

-- Create indexes for better query performance
CREATE INDEX idx_unlock_cycles_material ON public.material_unlock_cycles(material_id);
CREATE INDEX idx_unlock_cycles_status ON public.material_unlock_cycles(unlock_status);
CREATE INDEX idx_validity_tracker_material ON public.material_validity_tracker(material_id);
CREATE INDEX idx_validity_tracker_expiry ON public.material_validity_tracker(price_valid_until);
CREATE INDEX idx_supplier_materials_supplier ON public.supplier_materials(supplier_id);
CREATE INDEX idx_supplier_materials_material ON public.supplier_materials(material_id);

-- Create triggers for updated_at
CREATE TRIGGER update_material_unlock_cycles_updated_at
BEFORE UPDATE ON public.material_unlock_cycles
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_material_validity_tracker_updated_at
BEFORE UPDATE ON public.material_validity_tracker
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_supplier_materials_updated_at
BEFORE UPDATE ON public.supplier_materials
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();