-- Add structured summary fields to communication_log
ALTER TABLE public.communication_log
ADD COLUMN IF NOT EXISTS outcome_notes text,
ADD COLUMN IF NOT EXISTS interest_level text,
ADD COLUMN IF NOT EXISTS other_projects text;

-- Create communication_material_prices table for client's current purchase prices
CREATE TABLE IF NOT EXISTS public.communication_material_prices (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  communication_id uuid NOT NULL REFERENCES public.communication_log(id) ON DELETE CASCADE,
  material_id uuid NOT NULL REFERENCES public.materials(id) ON DELETE CASCADE,
  current_purchase_price numeric,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Create communication_material_needs table for requested materials
CREATE TABLE IF NOT EXISTS public.communication_material_needs (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  communication_id uuid NOT NULL REFERENCES public.communication_log(id) ON DELETE CASCADE,
  material_id uuid NOT NULL REFERENCES public.materials(id) ON DELETE CASCADE,
  notes text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on new tables
ALTER TABLE public.communication_material_prices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.communication_material_needs ENABLE ROW LEVEL SECURITY;

-- RLS policies for communication_material_prices
CREATE POLICY "All authenticated users can view communication material prices"
ON public.communication_material_prices
FOR SELECT
USING (true);

CREATE POLICY "Admins and procurement can insert communication material prices"
ON public.communication_material_prices
FOR INSERT
WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can update communication material prices"
ON public.communication_material_prices
FOR UPDATE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can delete communication material prices"
ON public.communication_material_prices
FOR DELETE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

-- RLS policies for communication_material_needs
CREATE POLICY "All authenticated users can view communication material needs"
ON public.communication_material_needs
FOR SELECT
USING (true);

CREATE POLICY "Admins and procurement can insert communication material needs"
ON public.communication_material_needs
FOR INSERT
WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can update communication material needs"
ON public.communication_material_needs
FOR UPDATE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can delete communication material needs"
ON public.communication_material_needs
FOR DELETE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_communication_material_prices_communication_id 
ON public.communication_material_prices(communication_id);

CREATE INDEX IF NOT EXISTS idx_communication_material_needs_communication_id 
ON public.communication_material_needs(communication_id);