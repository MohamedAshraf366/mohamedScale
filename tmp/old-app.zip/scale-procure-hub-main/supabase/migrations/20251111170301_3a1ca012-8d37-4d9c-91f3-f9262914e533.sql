-- Create quotation_items table for multi-item quotations
CREATE TABLE IF NOT EXISTS public.quotation_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  communication_log_id UUID NOT NULL REFERENCES public.communication_log(id) ON DELETE CASCADE,
  material_id UUID REFERENCES public.materials(id),
  district TEXT,
  quantity NUMERIC,
  unit_price NUMERIC,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.quotation_items ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "All authenticated users can view quotation items"
  ON public.quotation_items
  FOR SELECT
  USING (true);

CREATE POLICY "Admins and procurement can insert quotation items"
  ON public.quotation_items
  FOR INSERT
  WITH CHECK (
    check_user_role(auth.uid(), 'admin'::app_role) OR 
    check_user_role(auth.uid(), 'procurement_officer'::app_role)
  );

CREATE POLICY "Admins and procurement can update quotation items"
  ON public.quotation_items
  FOR UPDATE
  USING (
    check_user_role(auth.uid(), 'admin'::app_role) OR 
    check_user_role(auth.uid(), 'procurement_officer'::app_role)
  );

CREATE POLICY "Admins and procurement can delete quotation items"
  ON public.quotation_items
  FOR DELETE
  USING (
    check_user_role(auth.uid(), 'admin'::app_role) OR 
    check_user_role(auth.uid(), 'procurement_officer'::app_role)
  );

-- Add trigger for updated_at
CREATE TRIGGER update_quotation_items_updated_at
  BEFORE UPDATE ON public.quotation_items
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();