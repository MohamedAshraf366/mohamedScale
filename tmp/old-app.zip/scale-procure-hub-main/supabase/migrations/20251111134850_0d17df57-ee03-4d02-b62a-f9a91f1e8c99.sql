-- Update RLS policy to allow procurement officers to delete communications
DROP POLICY IF EXISTS "Admins can delete communications" ON communication_log;

CREATE POLICY "Admins and procurement can delete communications"
ON communication_log
FOR DELETE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));