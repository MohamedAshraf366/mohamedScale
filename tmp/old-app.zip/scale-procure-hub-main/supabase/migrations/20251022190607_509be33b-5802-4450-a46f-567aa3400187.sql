-- Drop existing problematic policies on user_roles
DROP POLICY IF EXISTS "Admins can view all roles" ON user_roles;
DROP POLICY IF EXISTS "Users can view their own roles" ON user_roles;

-- Create a security definer function to check user roles (bypasses RLS)
CREATE OR REPLACE FUNCTION public.check_user_role(check_user_id uuid, check_role app_role)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = check_user_id AND role = check_role
  );
END;
$$;

-- Create a security definer function to get user role (bypasses RLS)
CREATE OR REPLACE FUNCTION public.get_user_role(check_user_id uuid)
RETURNS app_role
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  user_role app_role;
BEGIN
  SELECT role INTO user_role FROM user_roles WHERE user_id = check_user_id LIMIT 1;
  RETURN user_role;
END;
$$;

-- Recreate user_roles policies without recursion
CREATE POLICY "Users can view their own roles"
ON user_roles
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all roles"
ON user_roles
FOR SELECT
USING (public.check_user_role(auth.uid(), 'admin'));

-- Update materials policies to use the helper function
DROP POLICY IF EXISTS "Admins and procurement can insert materials" ON materials;
DROP POLICY IF EXISTS "Admins and procurement can update materials" ON materials;
DROP POLICY IF EXISTS "Admins can delete materials" ON materials;

CREATE POLICY "Admins and procurement can insert materials"
ON materials
FOR INSERT
WITH CHECK (
  public.check_user_role(auth.uid(), 'admin') OR 
  public.check_user_role(auth.uid(), 'procurement_officer')
);

CREATE POLICY "Admins and procurement can update materials"
ON materials
FOR UPDATE
USING (
  public.check_user_role(auth.uid(), 'admin') OR 
  public.check_user_role(auth.uid(), 'procurement_officer')
);

CREATE POLICY "Admins can delete materials"
ON materials
FOR DELETE
USING (public.check_user_role(auth.uid(), 'admin'));

-- Update suppliers policies
DROP POLICY IF EXISTS "Admins and procurement can insert suppliers" ON suppliers;
DROP POLICY IF EXISTS "Admins and procurement can update suppliers" ON suppliers;
DROP POLICY IF EXISTS "Admins can delete suppliers" ON suppliers;

CREATE POLICY "Admins and procurement can insert suppliers"
ON suppliers
FOR INSERT
WITH CHECK (
  public.check_user_role(auth.uid(), 'admin') OR 
  public.check_user_role(auth.uid(), 'procurement_officer')
);

CREATE POLICY "Admins and procurement can update suppliers"
ON suppliers
FOR UPDATE
USING (
  public.check_user_role(auth.uid(), 'admin') OR 
  public.check_user_role(auth.uid(), 'procurement_officer')
);

CREATE POLICY "Admins can delete suppliers"
ON suppliers
FOR DELETE
USING (public.check_user_role(auth.uid(), 'admin'));

-- Update communication_log policies
DROP POLICY IF EXISTS "Admins and procurement can insert communications" ON communication_log;
DROP POLICY IF EXISTS "Admins and procurement can update communications" ON communication_log;
DROP POLICY IF EXISTS "Admins can delete communications" ON communication_log;

CREATE POLICY "Admins and procurement can insert communications"
ON communication_log
FOR INSERT
WITH CHECK (
  public.check_user_role(auth.uid(), 'admin') OR 
  public.check_user_role(auth.uid(), 'procurement_officer')
);

CREATE POLICY "Admins and procurement can update communications"
ON communication_log
FOR UPDATE
USING (
  public.check_user_role(auth.uid(), 'admin') OR 
  public.check_user_role(auth.uid(), 'procurement_officer')
);

CREATE POLICY "Admins can delete communications"
ON communication_log
FOR DELETE
USING (public.check_user_role(auth.uid(), 'admin'));

-- Update material_alt_suppliers policies
DROP POLICY IF EXISTS "Admins and procurement can manage material alt suppliers" ON material_alt_suppliers;

CREATE POLICY "Admins and procurement can manage material alt suppliers"
ON material_alt_suppliers
FOR ALL
USING (
  public.check_user_role(auth.uid(), 'admin') OR 
  public.check_user_role(auth.uid(), 'procurement_officer')
);