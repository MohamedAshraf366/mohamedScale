-- Add status_after column to follow_up_history table
ALTER TABLE public.follow_up_history 
ADD COLUMN IF NOT EXISTS status_after communication_status;

-- Update the trigger function to also update the parent communication's status
CREATE OR REPLACE FUNCTION public.update_communication_follow_up_date()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  UPDATE public.communication_log
  SET 
    follow_up_date = NEW.follow_up_date::date,
    status = COALESCE(NEW.status_after, status)
  WHERE id = NEW.communication_log_id;
  RETURN NEW;
END;
$function$;