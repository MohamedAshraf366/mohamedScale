-- Create enum for period types
CREATE TYPE period_type AS ENUM ('Monthly', 'Quarterly', 'Yearly');

-- Create the scale_targets table
CREATE TABLE public.scale_targets (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  kpi_name TEXT NOT NULL,
  period_type period_type NOT NULL,
  period_value TEXT NOT NULL,
  target_value NUMERIC NOT NULL,
  explanation TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.scale_targets ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "All authenticated users can view scale targets"
ON public.scale_targets
FOR SELECT
USING (true);

CREATE POLICY "Admins and procurement can insert scale targets"
ON public.scale_targets
FOR INSERT
WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can update scale targets"
ON public.scale_targets
FOR UPDATE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can delete scale targets"
ON public.scale_targets
FOR DELETE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_scale_targets_updated_at
BEFORE UPDATE ON public.scale_targets
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();