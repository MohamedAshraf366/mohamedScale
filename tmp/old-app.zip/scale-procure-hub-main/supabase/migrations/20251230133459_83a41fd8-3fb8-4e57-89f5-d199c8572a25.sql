-- Add payment fields to operations_orders table
ALTER TABLE public.operations_orders
ADD COLUMN payment_status text NOT NULL DEFAULT 'not_paid',
ADD COLUMN first_payment_proof_url text,
ADD COLUMN final_payment_proof_url text;

-- Add comment for clarity
COMMENT ON COLUMN public.operations_orders.payment_status IS 'Payment status at conversion: not_paid, first_payment_received, payment_completed';
COMMENT ON COLUMN public.operations_orders.first_payment_proof_url IS 'URL to first payment proof attachment';
COMMENT ON COLUMN public.operations_orders.final_payment_proof_url IS 'URL to final payment proof attachment';