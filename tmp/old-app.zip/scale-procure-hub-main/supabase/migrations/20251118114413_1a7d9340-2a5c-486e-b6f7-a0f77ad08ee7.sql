-- Add latitude and longitude to suppliers table
ALTER TABLE public.suppliers 
ADD COLUMN IF NOT EXISTS latitude numeric,
ADD COLUMN IF NOT EXISTS longitude numeric;

-- Create supplier_zones table if it doesn't exist
CREATE TABLE IF NOT EXISTS public.supplier_zones (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  supplier_id uuid NOT NULL REFERENCES public.suppliers(id) ON DELETE CASCADE,
  zone_name text NOT NULL,
  delivery_price numeric NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on supplier_zones
ALTER TABLE public.supplier_zones ENABLE ROW LEVEL SECURITY;

-- RLS policies for supplier_zones
CREATE POLICY "All authenticated users can view supplier zones"
ON public.supplier_zones
FOR SELECT
USING (true);

CREATE POLICY "Admins and procurement can insert supplier zones"
ON public.supplier_zones
FOR INSERT
WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can update supplier zones"
ON public.supplier_zones
FOR UPDATE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can delete supplier zones"
ON public.supplier_zones
FOR DELETE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

-- Add updated_at trigger
CREATE TRIGGER update_supplier_zones_updated_at
BEFORE UPDATE ON public.supplier_zones
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();