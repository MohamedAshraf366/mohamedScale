-- Add subcategory_name column to communication_material_needs table
ALTER TABLE public.communication_material_needs 
ADD COLUMN IF NOT EXISTS subcategory_name text;