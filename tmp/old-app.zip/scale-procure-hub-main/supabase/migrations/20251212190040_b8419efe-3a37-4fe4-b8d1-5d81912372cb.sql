-- Create material price history table
CREATE TABLE public.material_price_history (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  material_id UUID NOT NULL REFERENCES public.materials(id) ON DELETE CASCADE,
  supplier_id UUID NOT NULL REFERENCES public.suppliers(id) ON DELETE CASCADE,
  unit_price NUMERIC,
  manufacturer_price NUMERIC,
  delivery_price NUMERIC,
  recorded_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  recorded_by UUID,
  change_reason TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.material_price_history ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "All authenticated users can view price history"
ON public.material_price_history
FOR SELECT
USING (true);

CREATE POLICY "Admins and procurement can insert price history"
ON public.material_price_history
FOR INSERT
WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can delete price history"
ON public.material_price_history
FOR DELETE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

-- Create index for faster queries
CREATE INDEX idx_material_price_history_material ON public.material_price_history(material_id);
CREATE INDEX idx_material_price_history_supplier ON public.material_price_history(supplier_id);
CREATE INDEX idx_material_price_history_recorded_at ON public.material_price_history(recorded_at DESC);

-- Create function to automatically record price changes
CREATE OR REPLACE FUNCTION public.record_price_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Only record if prices actually changed
  IF (OLD.unit_price IS DISTINCT FROM NEW.unit_price) OR 
     (OLD.manufacturer_price IS DISTINCT FROM NEW.manufacturer_price) OR 
     (OLD.delivery_price IS DISTINCT FROM NEW.delivery_price) THEN
    INSERT INTO public.material_price_history (
      material_id,
      supplier_id,
      unit_price,
      manufacturer_price,
      delivery_price,
      recorded_by
    ) VALUES (
      NEW.material_id,
      NEW.supplier_id,
      NEW.unit_price,
      NEW.manufacturer_price,
      NEW.delivery_price,
      auth.uid()
    );
  END IF;
  RETURN NEW;
END;
$$;

-- Create trigger on material_alt_suppliers for updates
CREATE TRIGGER trigger_record_price_change
AFTER UPDATE ON public.material_alt_suppliers
FOR EACH ROW
EXECUTE FUNCTION public.record_price_change();

-- Also record initial prices on insert
CREATE OR REPLACE FUNCTION public.record_initial_price()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.material_price_history (
    material_id,
    supplier_id,
    unit_price,
    manufacturer_price,
    delivery_price,
    recorded_by
  ) VALUES (
    NEW.material_id,
    NEW.supplier_id,
    NEW.unit_price,
    NEW.manufacturer_price,
    NEW.delivery_price,
    auth.uid()
  );
  RETURN NEW;
END;
$$;

CREATE TRIGGER trigger_record_initial_price
AFTER INSERT ON public.material_alt_suppliers
FOR EACH ROW
EXECUTE FUNCTION public.record_initial_price();