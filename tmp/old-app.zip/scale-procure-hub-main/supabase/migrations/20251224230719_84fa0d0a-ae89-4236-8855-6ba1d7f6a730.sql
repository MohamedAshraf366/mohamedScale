-- Create shipments table for delivery tracking
CREATE TABLE public.shipments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  shipment_code text UNIQUE,
  supplier_id uuid REFERENCES public.suppliers(id) ON DELETE SET NULL,
  client_name text NOT NULL,
  origin text NOT NULL,
  destination text NOT NULL,
  items_description text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'in_transit', 'delivered', 'cancelled')),
  
  -- Scheduling times
  scheduled_departure timestamptz,
  scheduled_arrival timestamptz,
  actual_departure timestamptz,
  actual_arrival timestamptz,
  
  -- Delivery status tier (calculated on delivery)
  delivery_status text CHECK (delivery_status IN ('on_time', 'slightly_delayed', 'critically_delayed')),
  delay_minutes integer DEFAULT 0,
  
  -- Vehicle assignment
  vehicle_id text,
  driver_name text,
  driver_phone text,
  
  -- Progress tracking
  progress_percent integer DEFAULT 0 CHECK (progress_percent >= 0 AND progress_percent <= 100),
  
  -- Metadata
  notes text,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT NOW(),
  updated_at timestamptz NOT NULL DEFAULT NOW()
);

-- Create supplier issue tracker for Critically Delayed entries
CREATE TABLE public.supplier_issues (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  supplier_id uuid NOT NULL REFERENCES public.suppliers(id) ON DELETE CASCADE,
  shipment_id uuid REFERENCES public.shipments(id) ON DELETE SET NULL,
  issue_type text NOT NULL CHECK (issue_type IN ('critically_delayed', 'quality_issue', 'pricing_issue', 'communication_issue')),
  severity text NOT NULL DEFAULT 'major' CHECK (severity IN ('minor', 'major', 'critical')),
  description text,
  is_resolved boolean DEFAULT false,
  resolved_at timestamptz,
  resolved_by uuid,
  created_at timestamptz NOT NULL DEFAULT NOW(),
  updated_at timestamptz NOT NULL DEFAULT NOW()
);

-- Add at_risk status and consecutive on-time tracking to suppliers
ALTER TABLE public.suppliers
ADD COLUMN IF NOT EXISTS is_at_risk boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS at_risk_since timestamptz,
ADD COLUMN IF NOT EXISTS consecutive_on_time_count integer DEFAULT 0;

-- Create indexes for efficient queries
CREATE INDEX IF NOT EXISTS idx_shipments_status ON public.shipments(status);
CREATE INDEX IF NOT EXISTS idx_shipments_supplier ON public.shipments(supplier_id);
CREATE INDEX IF NOT EXISTS idx_shipments_scheduled_arrival ON public.shipments(scheduled_arrival);
CREATE INDEX IF NOT EXISTS idx_supplier_issues_supplier ON public.supplier_issues(supplier_id);
CREATE INDEX IF NOT EXISTS idx_supplier_issues_unresolved ON public.supplier_issues(supplier_id) WHERE is_resolved = false;

-- Function to calculate delivery status tier when marking as delivered
CREATE OR REPLACE FUNCTION public.calculate_delivery_status()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  delay_mins integer;
  status_tier text;
  minor_penalty numeric := 0.1;  -- Minor penalty for slightly delayed
  major_penalty numeric := 0.5;  -- Major penalty for critically delayed
  current_rating numeric;
BEGIN
  -- Only process when status changes to 'delivered' and actual_arrival is set
  IF NEW.status = 'delivered' AND NEW.actual_arrival IS NOT NULL AND NEW.scheduled_arrival IS NOT NULL THEN
    -- Calculate delay in minutes
    delay_mins := EXTRACT(EPOCH FROM (NEW.actual_arrival - NEW.scheduled_arrival)) / 60;
    
    -- Determine delivery status tier
    IF delay_mins <= 0 THEN
      status_tier := 'on_time';
    ELSIF delay_mins < 120 THEN
      status_tier := 'slightly_delayed';
    ELSE
      status_tier := 'critically_delayed';
    END IF;
    
    -- Update the shipment record
    NEW.delivery_status := status_tier;
    NEW.delay_minutes := GREATEST(0, delay_mins);
    
    -- Update supplier metrics if supplier is assigned
    IF NEW.supplier_id IS NOT NULL THEN
      -- Get current rating
      SELECT COALESCE(rating, 3) INTO current_rating FROM suppliers WHERE id = NEW.supplier_id;
      
      IF status_tier = 'on_time' THEN
        -- Increment consecutive on-time counter
        UPDATE suppliers SET 
          consecutive_on_time_count = consecutive_on_time_count + 1,
          -- If at risk and reached 5 consecutive on-time, clear at_risk status
          is_at_risk = CASE 
            WHEN is_at_risk AND consecutive_on_time_count >= 4 THEN false 
            ELSE is_at_risk 
          END,
          at_risk_since = CASE 
            WHEN is_at_risk AND consecutive_on_time_count >= 4 THEN NULL 
            ELSE at_risk_since 
          END,
          updated_at = NOW()
        WHERE id = NEW.supplier_id;
        
      ELSIF status_tier = 'slightly_delayed' THEN
        -- Minor penalty and reset consecutive counter
        UPDATE suppliers SET 
          rating = GREATEST(1, COALESCE(rating, 3) - minor_penalty),
          consecutive_on_time_count = 0,
          updated_at = NOW()
        WHERE id = NEW.supplier_id;
        
      ELSIF status_tier = 'critically_delayed' THEN
        -- Major penalty, flag as at risk, reset counter
        UPDATE suppliers SET 
          rating = GREATEST(1, COALESCE(rating, 3) - major_penalty),
          is_at_risk = true,
          at_risk_since = COALESCE(at_risk_since, NOW()),
          consecutive_on_time_count = 0,
          updated_at = NOW()
        WHERE id = NEW.supplier_id;
        
        -- Create issue tracker entry
        INSERT INTO supplier_issues (supplier_id, shipment_id, issue_type, severity, description)
        VALUES (
          NEW.supplier_id, 
          NEW.id, 
          'critically_delayed', 
          'major',
          'Delivery delayed by ' || delay_mins || ' minutes (Shipment: ' || COALESCE(NEW.shipment_code, NEW.id::text) || ')'
        );
      END IF;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger for delivery status calculation
DROP TRIGGER IF EXISTS trigger_calculate_delivery_status ON public.shipments;
CREATE TRIGGER trigger_calculate_delivery_status
  BEFORE UPDATE ON public.shipments
  FOR EACH ROW
  WHEN (NEW.status = 'delivered' AND OLD.status != 'delivered')
  EXECUTE FUNCTION public.calculate_delivery_status();

-- Also trigger on insert if inserting as delivered
DROP TRIGGER IF EXISTS trigger_calculate_delivery_status_insert ON public.shipments;
CREATE TRIGGER trigger_calculate_delivery_status_insert
  BEFORE INSERT ON public.shipments
  FOR EACH ROW
  WHEN (NEW.status = 'delivered')
  EXECUTE FUNCTION public.calculate_delivery_status();

-- Enable RLS on new tables
ALTER TABLE public.shipments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.supplier_issues ENABLE ROW LEVEL SECURITY;

-- RLS policies for shipments
CREATE POLICY "All authenticated users can view shipments"
  ON public.shipments FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins and procurement can insert shipments"
  ON public.shipments FOR INSERT
  TO authenticated
  WITH CHECK (check_user_role(auth.uid(), 'admin') OR check_user_role(auth.uid(), 'procurement_officer'));

CREATE POLICY "Admins and procurement can update shipments"
  ON public.shipments FOR UPDATE
  TO authenticated
  USING (check_user_role(auth.uid(), 'admin') OR check_user_role(auth.uid(), 'procurement_officer'));

CREATE POLICY "Admins can delete shipments"
  ON public.shipments FOR DELETE
  TO authenticated
  USING (check_user_role(auth.uid(), 'admin'));

-- RLS policies for supplier_issues
CREATE POLICY "All authenticated users can view supplier issues"
  ON public.supplier_issues FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins and procurement can insert supplier issues"
  ON public.supplier_issues FOR INSERT
  TO authenticated
  WITH CHECK (check_user_role(auth.uid(), 'admin') OR check_user_role(auth.uid(), 'procurement_officer'));

CREATE POLICY "Admins and procurement can update supplier issues"
  ON public.supplier_issues FOR UPDATE
  TO authenticated
  USING (check_user_role(auth.uid(), 'admin') OR check_user_role(auth.uid(), 'procurement_officer'));

CREATE POLICY "Admins can delete supplier issues"
  ON public.supplier_issues FOR DELETE
  TO authenticated
  USING (check_user_role(auth.uid(), 'admin'));

-- Add triggers for updated_at
CREATE TRIGGER update_shipments_updated_at
  BEFORE UPDATE ON public.shipments
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_supplier_issues_updated_at
  BEFORE UPDATE ON public.supplier_issues
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Function to generate shipment code
CREATE OR REPLACE FUNCTION public.generate_shipment_code()
RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
  next_number INTEGER;
  new_code TEXT;
BEGIN
  SELECT COALESCE(
    MAX(
      CAST(
        SUBSTRING(shipment_code FROM 'SH-(\d+)') AS INTEGER
      )
    ), 0
  ) + 1 INTO next_number
  FROM shipments
  WHERE shipment_code ~ '^SH-\d+$';
  
  new_code := 'SH-' || LPAD(next_number::TEXT, 5, '0');
  RETURN new_code;
END;
$$;

-- Trigger to auto-generate shipment code
CREATE OR REPLACE FUNCTION public.set_shipment_code()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.shipment_code IS NULL THEN
    NEW.shipment_code := generate_shipment_code();
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trigger_set_shipment_code ON public.shipments;
CREATE TRIGGER trigger_set_shipment_code
  BEFORE INSERT ON public.shipments
  FOR EACH ROW
  EXECUTE FUNCTION public.set_shipment_code();