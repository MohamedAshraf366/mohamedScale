-- Add city and location columns to quotation_items table
ALTER TABLE quotation_items 
ADD COLUMN city text,
ADD COLUMN location text;