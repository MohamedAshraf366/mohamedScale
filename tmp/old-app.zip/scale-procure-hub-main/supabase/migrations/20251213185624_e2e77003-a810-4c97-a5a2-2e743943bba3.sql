-- Drop the auto-creation trigger that creates follow-ups automatically
DROP TRIGGER IF EXISTS trigger_auto_create_followup ON public.communication_log;

-- Drop the auto-creation function
DROP FUNCTION IF EXISTS public.auto_create_followup_for_communication();