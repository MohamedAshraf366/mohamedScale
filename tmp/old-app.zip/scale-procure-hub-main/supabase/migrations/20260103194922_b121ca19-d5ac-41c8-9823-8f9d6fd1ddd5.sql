-- Create quarterly_tasks table for the development plan
CREATE TABLE public.quarterly_tasks (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  owner TEXT,
  area TEXT NOT NULL DEFAULT 'Sales',
  start_week INTEGER NOT NULL DEFAULT 1,
  end_week INTEGER NOT NULL DEFAULT 1,
  quarter TEXT NOT NULL DEFAULT 'Q1',
  year INTEGER NOT NULL DEFAULT EXTRACT(YEAR FROM CURRENT_DATE),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.quarterly_tasks ENABLE ROW LEVEL SECURITY;

-- Create policies for authenticated users
CREATE POLICY "Authenticated users can view quarterly tasks"
  ON public.quarterly_tasks
  FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can insert quarterly tasks"
  ON public.quarterly_tasks
  FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update quarterly tasks"
  ON public.quarterly_tasks
  FOR UPDATE
  USING (true);

CREATE POLICY "Authenticated users can delete quarterly tasks"
  ON public.quarterly_tasks
  FOR DELETE
  USING (true);

-- Create trigger for updated_at
CREATE TRIGGER update_quarterly_tasks_updated_at
  BEFORE UPDATE ON public.quarterly_tasks
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();