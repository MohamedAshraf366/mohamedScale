
-- Add new project fields to communication_log table
ALTER TABLE communication_log 
ADD COLUMN IF NOT EXISTS project_type TEXT,
ADD COLUMN IF NOT EXISTS project_size TEXT,
ADD COLUMN IF NOT EXISTS current_phase TEXT;

-- Add supplier_id to quotation_items table
ALTER TABLE quotation_items
ADD COLUMN IF NOT EXISTS supplier_id UUID;
