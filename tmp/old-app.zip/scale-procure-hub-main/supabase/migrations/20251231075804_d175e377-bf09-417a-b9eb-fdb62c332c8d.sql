-- Add in_pipeline column to opportunities table
ALTER TABLE public.opportunities 
ADD COLUMN IF NOT EXISTS in_pipeline boolean NOT NULL DEFAULT false;

-- Create function to auto-manage in_pipeline based on interest_level
CREATE OR REPLACE FUNCTION public.manage_opportunity_pipeline()
RETURNS TRIGGER AS $$
BEGIN
  -- Set in_pipeline based on interest_level
  -- High, Medium, Low = in pipeline
  -- Not interested, null, empty = not in pipeline
  IF NEW.interest_level IN ('High', 'Medium', 'Low') THEN
    NEW.in_pipeline := true;
  ELSE
    NEW.in_pipeline := false;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Create trigger for INSERT
DROP TRIGGER IF EXISTS set_opportunity_pipeline_on_insert ON public.opportunities;
CREATE TRIGGER set_opportunity_pipeline_on_insert
  BEFORE INSERT ON public.opportunities
  FOR EACH ROW
  EXECUTE FUNCTION public.manage_opportunity_pipeline();

-- Create trigger for UPDATE
DROP TRIGGER IF EXISTS set_opportunity_pipeline_on_update ON public.opportunities;
CREATE TRIGGER set_opportunity_pipeline_on_update
  BEFORE UPDATE ON public.opportunities
  FOR EACH ROW
  WHEN (OLD.interest_level IS DISTINCT FROM NEW.interest_level)
  EXECUTE FUNCTION public.manage_opportunity_pipeline();

-- Update existing opportunities to set in_pipeline correctly (only non-legacy, based on their current interest)
UPDATE public.opportunities
SET in_pipeline = CASE 
  WHEN interest_level IN ('High', 'Medium', 'Low') THEN true 
  ELSE false 
END;