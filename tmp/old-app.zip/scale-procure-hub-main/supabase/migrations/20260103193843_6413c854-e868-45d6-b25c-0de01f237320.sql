-- Create strategic_blockers table for Issues & Risks tracking
CREATE TABLE public.strategic_blockers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  area TEXT NOT NULL DEFAULT 'Sales',
  priority TEXT NOT NULL DEFAULT 'Medium',
  mitigation_owner TEXT,
  target_date DATE,
  status TEXT NOT NULL DEFAULT 'open',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.strategic_blockers ENABLE ROW LEVEL SECURITY;

-- Create policies for authenticated users
CREATE POLICY "Authenticated users can view strategic blockers" 
ON public.strategic_blockers 
FOR SELECT 
TO authenticated
USING (true);

CREATE POLICY "Authenticated users can insert strategic blockers" 
ON public.strategic_blockers 
FOR INSERT 
TO authenticated
WITH CHECK (true);

CREATE POLICY "Authenticated users can update strategic blockers" 
ON public.strategic_blockers 
FOR UPDATE 
TO authenticated
USING (true);

CREATE POLICY "Authenticated users can delete strategic blockers" 
ON public.strategic_blockers 
FOR DELETE 
TO authenticated
USING (true);

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_strategic_blockers_updated_at
BEFORE UPDATE ON public.strategic_blockers
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();