-- The issue is that "Admins can view all roles" policy itself calls check_user_role
-- which creates recursion. We need to remove it and only keep the simple policy.

DROP POLICY IF EXISTS "Admins can view all roles" ON user_roles;

-- Keep only the non-recursive policy
-- The SECURITY DEFINER functions will bypass RLS entirely