-- Add new columns to follow_up_history table for enhanced follow-up features
ALTER TABLE public.follow_up_history 
ADD COLUMN IF NOT EXISTS priority TEXT DEFAULT 'Medium' CHECK (priority IN ('High', 'Medium', 'Low')),
ADD COLUMN IF NOT EXISTS follow_up_type TEXT,
ADD COLUMN IF NOT EXISTS outcome TEXT CHECK (outcome IN ('Reached – Positive', 'Reached – Neutral', 'Reached – Negative', 'Not Reached', 'Postponed', NULL)),
ADD COLUMN IF NOT EXISTS reminder_enabled BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS attachments TEXT[] DEFAULT '{}';

-- Update status_after to include 'Delayed' status
-- First drop the old check constraint if it exists
ALTER TABLE public.follow_up_history 
DROP CONSTRAINT IF EXISTS follow_up_history_status_after_check;

-- Create storage bucket for follow-up attachments
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'follow-up-attachments',
  'follow-up-attachments',
  false,
  10485760, -- 10MB limit
  ARRAY['application/pdf', 'image/jpeg', 'image/png', 'image/gif', 'image/webp', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-excel']
)
ON CONFLICT (id) DO NOTHING;

-- Create storage policies for follow-up attachments
CREATE POLICY "Users can view their own follow-up attachments"
ON storage.objects FOR SELECT
USING (bucket_id = 'follow-up-attachments' AND auth.uid() IS NOT NULL);

CREATE POLICY "Users can upload follow-up attachments"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'follow-up-attachments' AND auth.uid() IS NOT NULL);

CREATE POLICY "Users can delete their own follow-up attachments"
ON storage.objects FOR DELETE
USING (bucket_id = 'follow-up-attachments' AND auth.uid() IS NOT NULL);