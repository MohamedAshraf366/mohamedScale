-- Create trigger function to auto-create Follow-up 1 for new communications
CREATE OR REPLACE FUNCTION public.auto_create_followup_for_communication()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  existing_followup_count INTEGER;
  followup_date TIMESTAMP WITH TIME ZONE;
  assigned_user_id UUID;
BEGIN
  -- Only proceed if interest_level is set to one of the valid values
  IF NEW.interest_level IS NULL OR NEW.interest_level NOT IN ('High', 'Medium', 'Low', 'Not interested') THEN
    RETURN NEW;
  END IF;

  -- Check for duplicate: if a follow-up with "Follow-up 1" already exists for this communication
  SELECT COUNT(*) INTO existing_followup_count
  FROM public.follow_up_history
  WHERE communication_log_id = NEW.id
    AND action ILIKE 'Follow-up 1%';

  -- If already exists, skip creation
  IF existing_followup_count > 0 THEN
    RETURN NEW;
  END IF;

  -- Calculate follow-up date: communication_date + 1 day, or now() + 1 day if null
  IF NEW.communication_date IS NOT NULL THEN
    followup_date := NEW.communication_date + INTERVAL '1 day';
  ELSE
    followup_date := NOW() + INTERVAL '1 day';
  END IF;

  -- Determine the user to assign: use owner_id if available, otherwise use a system default
  -- Since we're in a trigger, we can't use auth.uid() reliably, so we use owner_id
  assigned_user_id := COALESCE(NEW.owner_id, '00000000-0000-0000-0000-000000000000'::UUID);

  -- Create the auto Follow-up 1 record
  INSERT INTO public.follow_up_history (
    communication_log_id,
    follow_up_date,
    user_id,
    status_after,
    follow_up_type,
    action,
    notes,
    priority,
    reminder_enabled
  ) VALUES (
    NEW.id,
    followup_date,
    assigned_user_id,
    'Open',
    'General Follow-up',
    'Follow-up 1 – Send thank you message with the Scale profile and confirm the order.',
    'Automatic follow-up created from Communication Tracker.',
    'Medium',
    true
  );

  RETURN NEW;
END;
$$;

-- Create the trigger on communication_log table
DROP TRIGGER IF EXISTS trigger_auto_create_followup ON public.communication_log;

CREATE TRIGGER trigger_auto_create_followup
  AFTER INSERT ON public.communication_log
  FOR EACH ROW
  EXECUTE FUNCTION public.auto_create_followup_for_communication();