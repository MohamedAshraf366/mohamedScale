-- Create audit log table for follow-up history tracking
CREATE TABLE public.follow_up_audit_log (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  follow_up_id UUID NOT NULL,
  communication_log_id UUID NOT NULL REFERENCES public.communication_log(id) ON DELETE CASCADE,
  action TEXT NOT NULL CHECK (action IN ('created', 'updated', 'deleted')),
  changed_by UUID NOT NULL,
  changed_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  old_values JSONB,
  new_values JSONB,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.follow_up_audit_log ENABLE ROW LEVEL SECURITY;

-- Create policies for audit log
CREATE POLICY "All authenticated users can view audit logs"
  ON public.follow_up_audit_log
  FOR SELECT
  USING (true);

CREATE POLICY "Admins and procurement can insert audit logs"
  ON public.follow_up_audit_log
  FOR INSERT
  WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

-- Create index for faster queries
CREATE INDEX idx_follow_up_audit_log_follow_up_id ON public.follow_up_audit_log(follow_up_id);
CREATE INDEX idx_follow_up_audit_log_communication_log_id ON public.follow_up_audit_log(communication_log_id);
CREATE INDEX idx_follow_up_audit_log_changed_at ON public.follow_up_audit_log(changed_at DESC);