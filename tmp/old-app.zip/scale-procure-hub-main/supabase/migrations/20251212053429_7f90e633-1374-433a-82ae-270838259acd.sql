-- Add is_soft_quotation column to communication_log table
ALTER TABLE public.communication_log
ADD COLUMN is_soft_quotation boolean DEFAULT false;