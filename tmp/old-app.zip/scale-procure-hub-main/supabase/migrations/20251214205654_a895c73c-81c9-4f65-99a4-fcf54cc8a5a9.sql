-- Add quotation_sent field to communication_log table
-- This field tracks whether a quotation has been sent to the client
-- and determines the pipeline stage (Proposals Sent vs Qualified Leads)
ALTER TABLE public.communication_log 
ADD COLUMN IF NOT EXISTS quotation_sent boolean DEFAULT false;