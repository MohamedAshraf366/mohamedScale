-- Add supplier_code column to suppliers table
ALTER TABLE suppliers ADD COLUMN supplier_code TEXT UNIQUE;

-- Create function to generate supplier code
CREATE OR REPLACE FUNCTION generate_supplier_code()
RETURNS TEXT AS $$
DECLARE
  next_number INTEGER;
  new_code TEXT;
BEGIN
  -- Get the highest number from existing codes
  SELECT COALESCE(
    MAX(
      CAST(
        SUBSTRING(supplier_code FROM 'SUP-(\d+)') AS INTEGER
      )
    ), 0
  ) + 1 INTO next_number
  FROM suppliers
  WHERE supplier_code ~ '^SUP-\d+$';
  
  -- Format the new code with leading zeros (SUP-001, SUP-002, etc.)
  new_code := 'SUP-' || LPAD(next_number::TEXT, 3, '0');
  
  RETURN new_code;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to auto-generate supplier code on insert
CREATE OR REPLACE FUNCTION set_supplier_code()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.supplier_code IS NULL THEN
    NEW.supplier_code := generate_supplier_code();
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_set_supplier_code
BEFORE INSERT ON suppliers
FOR EACH ROW
EXECUTE FUNCTION set_supplier_code();

-- Update existing suppliers with codes
DO $$
DECLARE
  supplier_record RECORD;
  counter INTEGER := 1;
BEGIN
  FOR supplier_record IN 
    SELECT id FROM suppliers WHERE supplier_code IS NULL ORDER BY created_at
  LOOP
    UPDATE suppliers 
    SET supplier_code = 'SUP-' || LPAD(counter::TEXT, 3, '0')
    WHERE id = supplier_record.id;
    counter := counter + 1;
  END LOOP;
END $$;