-- Create sales_targets table
CREATE TABLE public.sales_targets (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  metric text NOT NULL,
  value text NOT NULL,
  explanation text NOT NULL,
  display_order integer NOT NULL DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.sales_targets ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "All authenticated users can view sales targets"
ON public.sales_targets
FOR SELECT
USING (true);

CREATE POLICY "Admins and procurement can insert sales targets"
ON public.sales_targets
FOR INSERT
WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can update sales targets"
ON public.sales_targets
FOR UPDATE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can delete sales targets"
ON public.sales_targets
FOR DELETE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

-- Create trigger for updated_at
CREATE TRIGGER update_sales_targets_updated_at
BEFORE UPDATE ON public.sales_targets
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default sales targets
INSERT INTO public.sales_targets (metric, value, explanation, display_order) VALUES
('Annual Target', 'SAR 6,000,000', 'Total deals value for 2026', 1),
('Average Deal Size', 'SAR 22,000', 'Average value per confirmed deal', 2),
('Qualification Ratio', '20%', '% of total leads that meet Scale''s ideal client profile', 3),
('Closing Ratio (Qualified → Deal)', '35%', '% of qualified leads that convert into orders', 4),
('Retention Rate', '50%', 'Portion of clients placing repeat orders', 5),
('Monthly Revenue Target', '≈ SAR 0.5M', 'Required to reach SAR 6M annually', 6);