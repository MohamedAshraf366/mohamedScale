-- Add client_response column to follow_up_history table
ALTER TABLE public.follow_up_history 
ADD COLUMN client_response text;