-- Add district column to communication_log table
ALTER TABLE communication_log ADD COLUMN IF NOT EXISTS district text;