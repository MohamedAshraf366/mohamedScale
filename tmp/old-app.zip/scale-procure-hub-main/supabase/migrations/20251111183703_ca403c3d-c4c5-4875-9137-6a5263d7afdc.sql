-- Enable realtime for communication_log table
ALTER TABLE communication_log REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE communication_log;

-- Enable realtime for quotation_items table
ALTER TABLE quotation_items REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE quotation_items;