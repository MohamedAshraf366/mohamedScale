-- Add follow_up_channel column to follow_up_history table
ALTER TABLE public.follow_up_history
ADD COLUMN follow_up_channel text;