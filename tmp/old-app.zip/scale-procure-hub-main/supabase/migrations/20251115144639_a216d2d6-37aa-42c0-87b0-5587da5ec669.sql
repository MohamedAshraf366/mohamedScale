-- Create table for tracking role changes
CREATE TABLE public.user_role_changes (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  changed_by uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  previous_role app_role NOT NULL,
  new_role app_role NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.user_role_changes ENABLE ROW LEVEL SECURITY;

-- Allow admins to view all role change logs
CREATE POLICY "Admins can view all role changes"
ON user_role_changes
FOR SELECT
TO authenticated
USING (check_user_role(auth.uid(), 'admin'));

-- Allow admins to insert role change logs
CREATE POLICY "Admins can insert role changes"
ON user_role_changes
FOR INSERT
TO authenticated
WITH CHECK (check_user_role(auth.uid(), 'admin'));

-- Create index for better query performance
CREATE INDEX idx_user_role_changes_user_id ON public.user_role_changes(user_id);
CREATE INDEX idx_user_role_changes_created_at ON public.user_role_changes(created_at DESC);