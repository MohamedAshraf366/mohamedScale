-- Add unit_price column to communication_log table
ALTER TABLE public.communication_log 
ADD COLUMN unit_price numeric;