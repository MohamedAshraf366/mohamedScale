-- Add new columns to suppliers table
ALTER TABLE public.suppliers 
ADD COLUMN supplier_type text CHECK (supplier_type IN ('Manufacturer', 'Distributor', 'Both')),
ADD COLUMN coverage text[] DEFAULT '{}',
ADD COLUMN status text DEFAULT 'Active' CHECK (status IN ('Active', 'Inactive')),
ADD COLUMN total_orders integer DEFAULT 0,
ADD COLUMN on_time_delivery_percent numeric DEFAULT 0 CHECK (on_time_delivery_percent >= 0 AND on_time_delivery_percent <= 100);

-- Add new columns to material_alt_suppliers table
ALTER TABLE public.material_alt_suppliers
ADD COLUMN moq numeric,
ADD COLUMN price_valid_until date,
ADD COLUMN material_notes text;

-- Create supplier_quotations table for file uploads
CREATE TABLE public.supplier_quotations (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  supplier_id uuid NOT NULL REFERENCES public.suppliers(id) ON DELETE CASCADE,
  file_url text NOT NULL,
  file_name text NOT NULL,
  title text,
  quotation_date date NOT NULL,
  notes text,
  uploaded_by uuid,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Create junction table for quotation-material relationships
CREATE TABLE public.supplier_quotation_materials (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  quotation_id uuid NOT NULL REFERENCES public.supplier_quotations(id) ON DELETE CASCADE,
  material_id uuid NOT NULL REFERENCES public.materials(id) ON DELETE CASCADE,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(quotation_id, material_id)
);

-- Enable RLS on new tables
ALTER TABLE public.supplier_quotations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.supplier_quotation_materials ENABLE ROW LEVEL SECURITY;

-- RLS policies for supplier_quotations
CREATE POLICY "All authenticated users can view supplier quotations"
ON public.supplier_quotations FOR SELECT
USING (true);

CREATE POLICY "Admins and procurement can insert supplier quotations"
ON public.supplier_quotations FOR INSERT
WITH CHECK (
  public.check_user_role(auth.uid(), 'admin'::public.app_role) 
  OR public.check_user_role(auth.uid(), 'procurement_officer'::public.app_role)
);

CREATE POLICY "Admins and procurement can update supplier quotations"
ON public.supplier_quotations FOR UPDATE
USING (
  public.check_user_role(auth.uid(), 'admin'::public.app_role) 
  OR public.check_user_role(auth.uid(), 'procurement_officer'::public.app_role)
);

CREATE POLICY "Admins and procurement can delete supplier quotations"
ON public.supplier_quotations FOR DELETE
USING (
  public.check_user_role(auth.uid(), 'admin'::public.app_role) 
  OR public.check_user_role(auth.uid(), 'procurement_officer'::public.app_role)
);

-- RLS policies for supplier_quotation_materials
CREATE POLICY "All authenticated users can view supplier quotation materials"
ON public.supplier_quotation_materials FOR SELECT
USING (true);

CREATE POLICY "Admins and procurement can insert supplier quotation materials"
ON public.supplier_quotation_materials FOR INSERT
WITH CHECK (
  public.check_user_role(auth.uid(), 'admin'::public.app_role) 
  OR public.check_user_role(auth.uid(), 'procurement_officer'::public.app_role)
);

CREATE POLICY "Admins and procurement can delete supplier quotation materials"
ON public.supplier_quotation_materials FOR DELETE
USING (
  public.check_user_role(auth.uid(), 'admin'::public.app_role) 
  OR public.check_user_role(auth.uid(), 'procurement_officer'::public.app_role)
);