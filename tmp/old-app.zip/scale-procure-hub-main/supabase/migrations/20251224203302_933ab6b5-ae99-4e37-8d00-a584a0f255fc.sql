-- Add quality_rating and coverage_zones to material_unlock_suppliers
ALTER TABLE public.material_unlock_suppliers 
ADD COLUMN IF NOT EXISTS quality_rating integer CHECK (quality_rating >= 1 AND quality_rating <= 5),
ADD COLUMN IF NOT EXISTS coverage_zones uuid[] DEFAULT '{}';

-- Create index for coverage zones queries
CREATE INDEX IF NOT EXISTS idx_material_unlock_suppliers_coverage_zones 
ON public.material_unlock_suppliers USING GIN (coverage_zones);

-- Add comment for documentation
COMMENT ON COLUMN public.material_unlock_suppliers.quality_rating IS 'Manual quality rating from 1-5';
COMMENT ON COLUMN public.material_unlock_suppliers.coverage_zones IS 'Array of zone UUIDs this supplier covers';