-- Create general_tasks table for standalone tasks
CREATE TABLE public.general_tasks (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  due_date TIMESTAMP WITH TIME ZONE,
  assigned_to TEXT NOT NULL,
  priority TEXT DEFAULT 'Medium',
  status TEXT DEFAULT 'Open',
  attachments TEXT[] DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_by UUID
);

-- Enable Row Level Security
ALTER TABLE public.general_tasks ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "All authenticated users can view general tasks" 
ON public.general_tasks 
FOR SELECT 
USING (true);

CREATE POLICY "Admins and procurement can insert general tasks" 
ON public.general_tasks 
FOR INSERT 
WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can update general tasks" 
ON public.general_tasks 
FOR UPDATE 
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can delete general tasks" 
ON public.general_tasks 
FOR DELETE 
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_general_tasks_updated_at
BEFORE UPDATE ON public.general_tasks
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();