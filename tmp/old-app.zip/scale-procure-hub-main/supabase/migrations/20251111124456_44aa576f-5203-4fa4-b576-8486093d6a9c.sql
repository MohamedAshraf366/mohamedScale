-- Change category from enum to text to allow dynamic categories
ALTER TABLE materials 
  ALTER COLUMN category TYPE text USING category::text;

-- Drop the enum type since it's no longer needed
DROP TYPE IF EXISTS material_category CASCADE;