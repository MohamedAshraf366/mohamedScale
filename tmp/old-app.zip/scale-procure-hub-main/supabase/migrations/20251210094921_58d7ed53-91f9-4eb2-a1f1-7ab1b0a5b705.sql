-- First drop the existing trigger that depends on the function
DROP TRIGGER IF EXISTS trigger_auto_create_followup ON public.communication_log;

-- Now we can replace the function
CREATE OR REPLACE FUNCTION public.auto_create_followup_for_communication()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  existing_followup_count INTEGER;
  followup_date TIMESTAMP WITH TIME ZONE;
  assigned_user_id UUID;
  base_date TIMESTAMP WITH TIME ZONE;
BEGIN
  -- Only proceed if interest_level is set to one of the valid values
  IF NEW.interest_level IS NULL OR NEW.interest_level NOT IN ('High', 'Medium', 'Low', 'Not interested') THEN
    RETURN NEW;
  END IF;

  -- Check for duplicate: if a follow-up with "Follow-up 1" already exists for this communication
  SELECT COUNT(*) INTO existing_followup_count
  FROM public.follow_up_history
  WHERE communication_log_id = NEW.id
    AND action ILIKE '%Follow-up 1%';

  -- If already exists, skip creation
  IF existing_followup_count > 0 THEN
    RETURN NEW;
  END IF;

  -- Calculate base date: communication_date or now()
  IF NEW.communication_date IS NOT NULL THEN
    base_date := NEW.communication_date;
  ELSE
    base_date := NOW();
  END IF;
  
  followup_date := base_date + INTERVAL '1 day';

  -- Determine the user to assign
  assigned_user_id := COALESCE(NEW.owner_id, '00000000-0000-0000-0000-000000000000'::UUID);

  -- Create Follow-up 1 for ALL interested levels (including Not interested)
  INSERT INTO public.follow_up_history (
    communication_log_id,
    follow_up_date,
    user_id,
    status_after,
    follow_up_type,
    action,
    notes,
    priority,
    reminder_enabled
  ) VALUES (
    NEW.id,
    followup_date,
    assigned_user_id,
    'Open',
    'General Follow-up',
    'Follow-up 1 – Send thank you message and company profile',
    'Thank you for your time today. Please find attached our company profile. If you need anything or would like support with your upcoming requirements, I''m here to help anytime.',
    'Medium',
    true
  );

  -- If "Not interested", create additional follow-ups based on objection_type
  IF NEW.interest_level = 'Not interested' AND NEW.objection_type IS NOT NULL THEN
    
    -- Objection Type: Not Interested
    IF NEW.objection_type = 'Not Interested' THEN
      INSERT INTO public.follow_up_history (communication_log_id, follow_up_date, user_id, status_after, follow_up_type, action, notes, priority, reminder_enabled)
      VALUES 
        (NEW.id, followup_date + INTERVAL '1 day', assigned_user_id, 'Open', 'General Follow-up', 'Follow-up 2 – Ask for suitable time', 'No problem at all. When would be a suitable time for us to follow up with you again?', 'Medium', true),
        (NEW.id, followup_date + INTERVAL '4 days', assigned_user_id, 'Open', 'General Follow-up', 'Follow-up 3 – Suggest a date', 'Just checking in — would it work for you if we contact you again on the suggested date?', 'Medium', true),
        (NEW.id, followup_date + INTERVAL '11 days', assigned_user_id, 'Open', 'General Follow-up', 'Follow-up 4 – Ask for preferred timeframe', 'Happy to stay aligned — what timeframe works best for future follow-ups? Final Status: Cold Lead – Monitor Only', 'Medium', true);
    
    -- Objection Type: Price Too High
    ELSIF NEW.objection_type = 'Price Too High' THEN
      INSERT INTO public.follow_up_history (communication_log_id, follow_up_date, user_id, status_after, follow_up_type, action, notes, priority, reminder_enabled)
      VALUES 
        (NEW.id, followup_date + INTERVAL '1 day', assigned_user_id, 'Open', 'General Follow-up', 'Follow-up 2 – Explain value', 'We understand your concern. Our pricing reflects higher quality, faster delivery, and more reliable supply — ensuring fewer delays and better project outcomes.', 'Medium', true),
        (NEW.id, followup_date + INTERVAL '8 days', assigned_user_id, 'Open', 'General Follow-up', 'Follow-up 3 – Payment flexibility', 'We can offer more flexible payment options if needed. Let me know what terms work best for your situation.', 'Medium', true),
        (NEW.id, followup_date + INTERVAL '29 days', assigned_user_id, 'Open', 'General Follow-up', 'Follow-up 4 – Credit option', 'As our relationship grows, we can explore providing credit terms. Happy to discuss this further if helpful. Final Status: Price-Sensitive Lead', 'Medium', true);
    
    -- Objection Type: Specific Requirements Needed
    ELSIF NEW.objection_type = 'Specific Requirements Needed' THEN
      INSERT INTO public.follow_up_history (communication_log_id, follow_up_date, user_id, status_after, follow_up_type, action, notes, priority, reminder_enabled)
      VALUES 
        (NEW.id, followup_date + INTERVAL '1 day', assigned_user_id, 'Open', 'General Follow-up', 'Follow-up 2 – Share compliance', 'Our products meet all specifications. I can share certificates and technical documentation to confirm compliance.', 'Medium', true),
        (NEW.id, followup_date + INTERVAL '4 days', assigned_user_id, 'Open', 'General Follow-up', 'Follow-up 3 – Request exact specs', 'Could you please share the exact specifications your team requires? This helps ensure full alignment.', 'Medium', true),
        (NEW.id, followup_date + INTERVAL '11 days', assigned_user_id, 'Open', 'General Follow-up', 'Follow-up 4 – Contact technical approver', 'If possible, please connect us with the technical person who handles supplier approval. We can streamline this process directly with them. Final Status: Pending Technical Approval', 'Medium', true);
    
    -- Objection Type: Payment Terms Issue
    ELSIF NEW.objection_type = 'Payment Terms Issue' THEN
      INSERT INTO public.follow_up_history (communication_log_id, follow_up_date, user_id, status_after, follow_up_type, action, notes, priority, reminder_enabled)
      VALUES 
        (NEW.id, followup_date + INTERVAL '1 day', assigned_user_id, 'Open', 'General Follow-up', 'Follow-up 2 – Explain payment cycle', 'Our 3–5 day payment timeline is simple and hassle-free. I can guide you through the process at any time.', 'Medium', true),
        (NEW.id, followup_date + INTERVAL '8 days', assigned_user_id, 'Open', 'General Follow-up', 'Follow-up 3 – Improved terms with volume', 'As purchase volumes increase, we''ll be able to offer more flexible and improved payment terms.', 'Medium', true),
        (NEW.id, followup_date + INTERVAL '22 days', assigned_user_id, 'Open', 'General Follow-up', 'Follow-up 4 – Explain sourcing and negotiation', 'We follow a strong sourcing and negotiation method to secure better pricing and consistent quality — helping your projects run smoother. Final Status: Payment Concern Lead', 'Medium', true);
    
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

-- Recreate the trigger with original name
CREATE TRIGGER trigger_auto_create_followup
AFTER INSERT ON public.communication_log
FOR EACH ROW
EXECUTE FUNCTION public.auto_create_followup_for_communication();