-- Add new columns to materials table
ALTER TABLE public.materials
ADD COLUMN scale_price numeric,
ADD COLUMN market_price_min numeric,
ADD COLUMN market_price_avg numeric,
ADD COLUMN market_price_max numeric,
ADD COLUMN cumulative_order_quantity numeric DEFAULT 0;