-- Change uom from enum to text to allow dynamic units of measurement
ALTER TABLE materials 
  ALTER COLUMN uom TYPE text USING uom::text;

-- Drop the enum type since it's no longer needed
DROP TYPE IF EXISTS uom_type CASCADE;