-- Add DELETE policy for profiles table (admins only)
CREATE POLICY "Admins can delete profiles"
ON public.profiles
FOR DELETE
USING (check_user_role(auth.uid(), 'admin'::app_role));

-- Add DELETE policy for user_roles table (admins only)
CREATE POLICY "Admins can delete user roles"
ON public.user_roles
FOR DELETE
USING (check_user_role(auth.uid(), 'admin'::app_role));