-- Create client_segments table for client type/segment classification
CREATE TABLE IF NOT EXISTS public.client_segments (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  color text,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Insert default segments
INSERT INTO public.client_segments (name, color) VALUES 
  ('RED', '#ef4444'),
  ('Large Contractor', '#3b82f6'),
  ('SME', '#22c55e'),
  ('Other', '#6b7280')
ON CONFLICT DO NOTHING;

-- Enable RLS on client_segments
ALTER TABLE public.client_segments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "All authenticated users can view client segments"
ON public.client_segments FOR SELECT
USING (true);

CREATE POLICY "Admins can manage client segments"
ON public.client_segments FOR ALL
USING (check_user_role(auth.uid(), 'admin'::app_role));

-- Create clients table to aggregate client data
CREATE TABLE IF NOT EXISTS public.clients (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  company_name text NOT NULL,
  segment_id uuid REFERENCES public.client_segments(id),
  primary_contact_name text,
  primary_contact_phone text,
  city text,
  district text,
  interest_level text,
  assigned_to text,
  notes text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(company_name)
);

-- Enable RLS on clients
ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;

CREATE POLICY "All authenticated users can view clients"
ON public.clients FOR SELECT
USING (true);

CREATE POLICY "Admins and procurement can insert clients"
ON public.clients FOR INSERT
WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can update clients"
ON public.clients FOR UPDATE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins can delete clients"
ON public.clients FOR DELETE
USING (check_user_role(auth.uid(), 'admin'::app_role));

-- Create projects table linked to clients
CREATE TABLE IF NOT EXISTS public.projects (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  client_id uuid NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  name text NOT NULL,
  project_type text,
  project_size text,
  current_phase text,
  city text,
  district text,
  location text,
  status text DEFAULT 'Active',
  notes text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on projects
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;

CREATE POLICY "All authenticated users can view projects"
ON public.projects FOR SELECT
USING (true);

CREATE POLICY "Admins and procurement can insert projects"
ON public.projects FOR INSERT
WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can update projects"
ON public.projects FOR UPDATE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins can delete projects"
ON public.projects FOR DELETE
USING (check_user_role(auth.uid(), 'admin'::app_role));

-- Create opportunities table linked to projects
CREATE TABLE IF NOT EXISTS public.opportunities (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  project_id uuid NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  client_id uuid NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  name text NOT NULL,
  stage text DEFAULT 'Discovery',
  interest_level text,
  expected_value numeric,
  expected_close_date date,
  is_closed boolean DEFAULT false,
  won boolean,
  closed_at timestamp with time zone,
  assigned_to text,
  notes text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on opportunities
ALTER TABLE public.opportunities ENABLE ROW LEVEL SECURITY;

CREATE POLICY "All authenticated users can view opportunities"
ON public.opportunities FOR SELECT
USING (true);

CREATE POLICY "Admins and procurement can insert opportunities"
ON public.opportunities FOR INSERT
WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can update opportunities"
ON public.opportunities FOR UPDATE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins can delete opportunities"
ON public.opportunities FOR DELETE
USING (check_user_role(auth.uid(), 'admin'::app_role));

-- Add client_id foreign key to communication_log for linking legacy data
ALTER TABLE public.communication_log 
ADD COLUMN IF NOT EXISTS client_id uuid REFERENCES public.clients(id);

-- Add project_id and opportunity_id to communication_log for linking
ALTER TABLE public.communication_log 
ADD COLUMN IF NOT EXISTS project_id uuid REFERENCES public.projects(id);

ALTER TABLE public.communication_log 
ADD COLUMN IF NOT EXISTS opportunity_id uuid REFERENCES public.opportunities(id);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_projects_client_id ON public.projects(client_id);
CREATE INDEX IF NOT EXISTS idx_opportunities_project_id ON public.opportunities(project_id);
CREATE INDEX IF NOT EXISTS idx_opportunities_client_id ON public.opportunities(client_id);
CREATE INDEX IF NOT EXISTS idx_communication_log_client_id ON public.communication_log(client_id);
CREATE INDEX IF NOT EXISTS idx_communication_log_project_id ON public.communication_log(project_id);
CREATE INDEX IF NOT EXISTS idx_communication_log_opportunity_id ON public.communication_log(opportunity_id);
CREATE INDEX IF NOT EXISTS idx_clients_company_name ON public.clients(company_name);

-- Add triggers for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS update_clients_updated_at ON public.clients;
CREATE TRIGGER update_clients_updated_at
  BEFORE UPDATE ON public.clients
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_projects_updated_at ON public.projects;
CREATE TRIGGER update_projects_updated_at
  BEFORE UPDATE ON public.projects
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_opportunities_updated_at ON public.opportunities;
CREATE TRIGGER update_opportunities_updated_at
  BEFORE UPDATE ON public.opportunities
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();