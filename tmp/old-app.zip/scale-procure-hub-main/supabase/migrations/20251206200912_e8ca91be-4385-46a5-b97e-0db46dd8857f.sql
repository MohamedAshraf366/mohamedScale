-- Create comprehensive audit log table for all CRUD operations
CREATE TABLE public.audit_log (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  action TEXT NOT NULL CHECK (action IN ('created', 'updated', 'deleted')),
  module TEXT NOT NULL,
  record_id UUID NOT NULL,
  record_name TEXT,
  user_id UUID NOT NULL,
  old_values JSONB,
  new_values JSONB,
  changes JSONB,
  description TEXT
);

-- Create index for faster queries
CREATE INDEX idx_audit_log_created_at ON public.audit_log(created_at DESC);
CREATE INDEX idx_audit_log_module ON public.audit_log(module);
CREATE INDEX idx_audit_log_user_id ON public.audit_log(user_id);
CREATE INDEX idx_audit_log_record_id ON public.audit_log(record_id);

-- Enable Row Level Security
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;

-- RLS Policies: Only admins and procurement officers can view audit logs
CREATE POLICY "Admins and procurement can view audit logs"
ON public.audit_log
FOR SELECT
USING (
  check_user_role(auth.uid(), 'admin'::app_role) OR 
  check_user_role(auth.uid(), 'procurement_officer'::app_role)
);

-- All authenticated users can insert audit logs (their own actions get logged)
CREATE POLICY "Authenticated users can insert audit logs"
ON public.audit_log
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- No one can update or delete audit logs (immutable)
-- (No UPDATE or DELETE policies = append-only)