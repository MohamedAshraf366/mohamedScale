-- Enhance supplier_issues table with additional fields for comprehensive tracking
ALTER TABLE public.supplier_issues
ADD COLUMN IF NOT EXISTS source text DEFAULT 'manual_ops' CHECK (source IN ('auto_logistics', 'manual_sales', 'manual_ops')),
ADD COLUMN IF NOT EXISTS material_id uuid REFERENCES public.materials(id) ON DELETE SET NULL,
ADD COLUMN IF NOT EXISTS order_reference text,
ADD COLUMN IF NOT EXISTS status text DEFAULT 'open' CHECK (status IN ('open', 'in_investigation', 'resolved', 'escalated_to_renegotiation')),
ADD COLUMN IF NOT EXISTS supplier_justification text,
ADD COLUMN IF NOT EXISTS resolution_notes text,
ADD COLUMN IF NOT EXISTS assigned_to uuid,
ADD COLUMN IF NOT EXISTS escalation_date timestamptz,
ADD COLUMN IF NOT EXISTS linked_renegotiation_id uuid REFERENCES public.material_renegotiations(id) ON DELETE SET NULL,
ADD COLUMN IF NOT EXISTS reported_by uuid,
ADD COLUMN IF NOT EXISTS reported_at timestamptz DEFAULT NOW();

-- Update the issue_type check constraint to include all types
ALTER TABLE public.supplier_issues DROP CONSTRAINT IF EXISTS supplier_issues_issue_type_check;
ALTER TABLE public.supplier_issues ADD CONSTRAINT supplier_issues_issue_type_check 
  CHECK (issue_type IN ('critically_delayed', 'quality_issue', 'pricing_issue', 'communication_issue', 'delay', 'quality', 'price_dispute', 'other'));

-- Update existing 'critically_delayed' source to 'auto_logistics'
UPDATE public.supplier_issues SET source = 'auto_logistics' WHERE issue_type = 'critically_delayed';

-- Update calculate_delivery_status function to set source = 'auto_logistics'
CREATE OR REPLACE FUNCTION public.calculate_delivery_status()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  delay_mins integer;
  status_tier text;
  minor_penalty numeric := 0.1;
  major_penalty numeric := 0.5;
  current_rating numeric;
BEGIN
  IF NEW.status = 'delivered' AND NEW.actual_arrival IS NOT NULL AND NEW.scheduled_arrival IS NOT NULL THEN
    delay_mins := EXTRACT(EPOCH FROM (NEW.actual_arrival - NEW.scheduled_arrival)) / 60;
    
    IF delay_mins <= 0 THEN
      status_tier := 'on_time';
    ELSIF delay_mins < 120 THEN
      status_tier := 'slightly_delayed';
    ELSE
      status_tier := 'critically_delayed';
    END IF;
    
    NEW.delivery_status := status_tier;
    NEW.delay_minutes := GREATEST(0, delay_mins);
    
    IF NEW.supplier_id IS NOT NULL THEN
      SELECT COALESCE(rating, 3) INTO current_rating FROM suppliers WHERE id = NEW.supplier_id;
      
      IF status_tier = 'on_time' THEN
        UPDATE suppliers SET 
          consecutive_on_time_count = consecutive_on_time_count + 1,
          is_at_risk = CASE 
            WHEN is_at_risk AND consecutive_on_time_count >= 4 THEN false 
            ELSE is_at_risk 
          END,
          at_risk_since = CASE 
            WHEN is_at_risk AND consecutive_on_time_count >= 4 THEN NULL 
            ELSE at_risk_since 
          END,
          updated_at = NOW()
        WHERE id = NEW.supplier_id;
        
      ELSIF status_tier = 'slightly_delayed' THEN
        UPDATE suppliers SET 
          rating = GREATEST(1, COALESCE(rating, 3) - minor_penalty),
          consecutive_on_time_count = 0,
          updated_at = NOW()
        WHERE id = NEW.supplier_id;
        
      ELSIF status_tier = 'critically_delayed' THEN
        UPDATE suppliers SET 
          rating = GREATEST(1, COALESCE(rating, 3) - major_penalty),
          is_at_risk = true,
          at_risk_since = COALESCE(at_risk_since, NOW()),
          consecutive_on_time_count = 0,
          updated_at = NOW()
        WHERE id = NEW.supplier_id;
        
        -- Create issue tracker entry with auto_logistics source
        INSERT INTO supplier_issues (
          supplier_id, 
          shipment_id, 
          issue_type, 
          severity, 
          description,
          source,
          status,
          reported_at
        )
        VALUES (
          NEW.supplier_id, 
          NEW.id, 
          'critically_delayed', 
          'major',
          'Delivery delayed by ' || delay_mins || ' minutes (Shipment: ' || COALESCE(NEW.shipment_code, NEW.id::text) || ')',
          'auto_logistics',
          'open',
          NOW()
        );
      END IF;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Function to check and auto-create renegotiation when 3+ issues accumulate
CREATE OR REPLACE FUNCTION public.check_supplier_issues_escalation()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  unresolved_count integer;
  critical_count integer;
  total_issues_count integer;
  existing_reneg_id uuid;
  new_reneg_id uuid;
  supplier_name text;
  first_material_id uuid;
BEGIN
  -- Count unresolved and critical issues for this supplier
  SELECT 
    COUNT(*) FILTER (WHERE status NOT IN ('resolved')),
    COUNT(*) FILTER (WHERE severity = 'critical' AND status NOT IN ('resolved'))
  INTO unresolved_count, critical_count
  FROM supplier_issues
  WHERE supplier_id = NEW.supplier_id;
  
  total_issues_count := unresolved_count;
  
  -- If 3+ unresolved or critical issues, auto-create renegotiation
  IF total_issues_count >= 3 THEN
    -- Check if there's already an active renegotiation for this supplier
    SELECT id INTO existing_reneg_id
    FROM material_renegotiations
    WHERE supplier_id = NEW.supplier_id
      AND approval_status NOT IN ('rejected')
      AND renegotiation_status NOT IN ('completed', 'cancelled')
    LIMIT 1;
    
    -- Only create if no existing active renegotiation
    IF existing_reneg_id IS NULL THEN
      -- Get supplier name for notes
      SELECT name INTO supplier_name FROM suppliers WHERE id = NEW.supplier_id;
      
      -- Get first material associated with issues
      SELECT material_id INTO first_material_id
      FROM supplier_issues
      WHERE supplier_id = NEW.supplier_id AND material_id IS NOT NULL
      LIMIT 1;
      
      -- If no material from issues, get from supplier's materials
      IF first_material_id IS NULL THEN
        SELECT material_id INTO first_material_id
        FROM supplier_materials
        WHERE supplier_id = NEW.supplier_id
        LIMIT 1;
      END IF;
      
      -- If still no material, get from alt_suppliers
      IF first_material_id IS NULL THEN
        SELECT material_id INTO first_material_id
        FROM material_alt_suppliers
        WHERE supplier_id = NEW.supplier_id
        LIMIT 1;
      END IF;
      
      -- Only create renegotiation if we have a material
      IF first_material_id IS NOT NULL THEN
        INSERT INTO material_renegotiations (
          material_id,
          supplier_id,
          approval_status,
          supply_head_notes,
          renegotiation_status
        ) VALUES (
          first_material_id,
          NEW.supplier_id,
          'pending_supply_head',
          'Auto-created due to ' || total_issues_count || ' unresolved supplier issues. Supplier: ' || COALESCE(supplier_name, 'Unknown'),
          'pending'
        )
        RETURNING id INTO new_reneg_id;
        
        -- Update the issue to link to the renegotiation
        UPDATE supplier_issues
        SET 
          status = 'escalated_to_renegotiation',
          linked_renegotiation_id = new_reneg_id,
          escalation_date = NOW()
        WHERE id = NEW.id;
      END IF;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger for auto-escalation
DROP TRIGGER IF EXISTS trigger_check_issues_escalation ON public.supplier_issues;
CREATE TRIGGER trigger_check_issues_escalation
  AFTER INSERT ON public.supplier_issues
  FOR EACH ROW
  EXECUTE FUNCTION public.check_supplier_issues_escalation();

-- Create index for efficient queries
CREATE INDEX IF NOT EXISTS idx_supplier_issues_status ON public.supplier_issues(status);
CREATE INDEX IF NOT EXISTS idx_supplier_issues_severity ON public.supplier_issues(severity);
CREATE INDEX IF NOT EXISTS idx_supplier_issues_source ON public.supplier_issues(source);
CREATE INDEX IF NOT EXISTS idx_supplier_issues_material ON public.supplier_issues(material_id);