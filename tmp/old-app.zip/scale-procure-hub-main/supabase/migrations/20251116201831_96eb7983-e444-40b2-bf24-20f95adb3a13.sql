-- Fix search_path for the new function
CREATE OR REPLACE FUNCTION update_communication_follow_up_date()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.communication_log
  SET follow_up_date = NEW.follow_up_date::date
  WHERE id = NEW.communication_log_id;
  RETURN NEW;
END;
$$;