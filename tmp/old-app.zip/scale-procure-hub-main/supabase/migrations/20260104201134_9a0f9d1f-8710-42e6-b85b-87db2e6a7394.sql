-- Add opportunity_id column to follow_up_history
ALTER TABLE public.follow_up_history 
ADD COLUMN opportunity_id UUID REFERENCES public.opportunities(id) ON DELETE SET NULL;

-- Create index for faster lookups
CREATE INDEX idx_follow_up_history_opportunity_id ON public.follow_up_history(opportunity_id);