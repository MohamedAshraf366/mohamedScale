-- First, drop the foreign key constraint
ALTER TABLE communication_log 
DROP CONSTRAINT IF EXISTS communication_log_assigned_to_fkey;

-- Then change assigned_to column from UUID to TEXT to store assignee names
ALTER TABLE communication_log 
ALTER COLUMN assigned_to TYPE TEXT USING assigned_to::TEXT;