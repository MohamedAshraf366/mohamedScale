-- Create activity log table for sales targets
CREATE TABLE public.sales_target_activity_log (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  sales_target_id uuid REFERENCES public.sales_targets(id) ON DELETE SET NULL,
  user_id uuid NOT NULL,
  action text NOT NULL CHECK (action IN ('created', 'updated', 'deleted')),
  target_metric text,
  changes jsonb,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.sales_target_activity_log ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "All authenticated users can view activity logs"
ON public.sales_target_activity_log
FOR SELECT
USING (true);

CREATE POLICY "Admins and procurement can insert activity logs"
ON public.sales_target_activity_log
FOR INSERT
WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

-- Create index for better query performance
CREATE INDEX idx_sales_target_activity_log_target_id ON public.sales_target_activity_log(sales_target_id);
CREATE INDEX idx_sales_target_activity_log_created_at ON public.sales_target_activity_log(created_at DESC);