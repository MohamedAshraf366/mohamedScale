-- Update RLS policy to allow all authenticated users to insert materials
DROP POLICY IF EXISTS "Admins and procurement can insert materials" ON materials;

CREATE POLICY "All authenticated users can insert materials"
ON materials
FOR INSERT
TO authenticated
WITH CHECK (true);

-- Update the update policy as well to allow all authenticated users
DROP POLICY IF EXISTS "Admins and procurement can update materials" ON materials;

CREATE POLICY "All authenticated users can update materials"
ON materials
FOR UPDATE
TO authenticated
USING (true);