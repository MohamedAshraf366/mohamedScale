-- Create storage bucket for material images
INSERT INTO storage.buckets (id, name, public) VALUES ('material-images', 'material-images', true);

-- Create policy to allow authenticated users to upload images
CREATE POLICY "Authenticated users can upload material images"
ON storage.objects
FOR INSERT
WITH CHECK (bucket_id = 'material-images' AND auth.uid() IS NOT NULL);

-- Create policy to allow anyone to view material images (public bucket)
CREATE POLICY "Anyone can view material images"
ON storage.objects
FOR SELECT
USING (bucket_id = 'material-images');

-- Create policy to allow authenticated users to update their uploaded images
CREATE POLICY "Authenticated users can update material images"
ON storage.objects
FOR UPDATE
USING (bucket_id = 'material-images' AND auth.uid() IS NOT NULL);

-- Create policy to allow authenticated users to delete material images
CREATE POLICY "Authenticated users can delete material images"
ON storage.objects
FOR DELETE
USING (bucket_id = 'material-images' AND auth.uid() IS NOT NULL);