-- Add escalation tracking fields to material_validity_tracker
ALTER TABLE public.material_validity_tracker 
ADD COLUMN IF NOT EXISTS escalation_phase text DEFAULT 'none' CHECK (escalation_phase IN ('none', 'ai_attempt_1', 'ai_attempt_2', 'pending_officer', 'auto_confirmed', 'officer_confirmed', 'no_response_closed')),
ADD COLUMN IF NOT EXISTS escalation_started_at timestamptz,
ADD COLUMN IF NOT EXISTS last_ai_message_at timestamptz,
ADD COLUMN IF NOT EXISTS ai_attempt_count integer DEFAULT 0,
ADD COLUMN IF NOT EXISTS officer_assigned_at timestamptz,
ADD COLUMN IF NOT EXISTS confirmation_source text DEFAULT 'manual' CHECK (confirmation_source IN ('manual', 'sales_transaction', 'ai_outreach', 'officer_confirmed')),
ADD COLUMN IF NOT EXISTS last_confirmed_at timestamptz;

-- Create index for efficient querying of pending escalations
CREATE INDEX IF NOT EXISTS idx_validity_escalation_phase ON public.material_validity_tracker(escalation_phase) WHERE escalation_phase != 'none';

-- Create a function to auto-confirm when a closed deal is fulfilled
CREATE OR REPLACE FUNCTION public.auto_confirm_from_closed_deal()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- When a closed deal item is created, update the validity tracker
  UPDATE public.material_validity_tracker
  SET 
    escalation_phase = 'auto_confirmed',
    confirmation_source = 'sales_transaction',
    last_confirmed_at = NOW(),
    price_valid_until = NOW() + INTERVAL '30 days',
    is_active = true,
    updated_at = NOW()
  WHERE material_id = NEW.material_id
    AND escalation_phase IN ('ai_attempt_1', 'ai_attempt_2', 'pending_officer');
  
  RETURN NEW;
END;
$$;

-- Create trigger to auto-confirm on closed deal
DROP TRIGGER IF EXISTS trigger_auto_confirm_from_deal ON public.closed_deal_items;
CREATE TRIGGER trigger_auto_confirm_from_deal
  AFTER INSERT ON public.closed_deal_items
  FOR EACH ROW
  EXECUTE FUNCTION public.auto_confirm_from_closed_deal();

-- Create a table for escalation tasks (officer review required)
CREATE TABLE IF NOT EXISTS public.escalation_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  material_id uuid NOT NULL REFERENCES public.materials(id) ON DELETE CASCADE,
  supplier_id uuid REFERENCES public.suppliers(id) ON DELETE SET NULL,
  validity_tracker_id uuid REFERENCES public.material_validity_tracker(id) ON DELETE CASCADE,
  task_type text NOT NULL DEFAULT 'final_contact' CHECK (task_type IN ('final_contact', 'price_verification', 'supplier_outreach')),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed', 'cancelled')),
  assigned_to text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT NOW(),
  completed_at timestamptz,
  updated_at timestamptz NOT NULL DEFAULT NOW()
);

-- Enable RLS on escalation_tasks
ALTER TABLE public.escalation_tasks ENABLE ROW LEVEL SECURITY;

-- RLS policies for escalation_tasks (authenticated users can access)
CREATE POLICY "Authenticated users can view escalation tasks"
  ON public.escalation_tasks FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert escalation tasks"
  ON public.escalation_tasks FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update escalation tasks"
  ON public.escalation_tasks FOR UPDATE
  TO authenticated
  USING (true);

-- Create trigger to update updated_at
CREATE TRIGGER update_escalation_tasks_updated_at
  BEFORE UPDATE ON public.escalation_tasks
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();