-- Create activities table for client timeline
-- This stores all activity records linked to clients with legacy communication traceability

CREATE TABLE public.activities (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  opportunity_id UUID REFERENCES public.opportunities(id) ON DELETE SET NULL,
  project_id UUID REFERENCES public.projects(id) ON DELETE SET NULL,
  
  -- Activity type and content
  activity_type TEXT NOT NULL DEFAULT 'communication',
  channel TEXT,
  summary TEXT,
  notes TEXT,
  
  -- Activity metadata
  activity_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_by UUID,
  assigned_to TEXT,
  
  -- Interest and status (display only for legacy data)
  interest_level TEXT,
  legacy_status TEXT,
  
  -- Legacy traceability - link back to original communication
  legacy_communication_id UUID REFERENCES public.communication_log(id) ON DELETE SET NULL,
  
  -- Timestamps
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.activities ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "All authenticated users can view activities"
ON public.activities
FOR SELECT
USING (true);

CREATE POLICY "Admins and procurement can insert activities"
ON public.activities
FOR INSERT
WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can update activities"
ON public.activities
FOR UPDATE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can delete activities"
ON public.activities
FOR DELETE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

-- Create index for faster client lookups
CREATE INDEX idx_activities_client_id ON public.activities(client_id);
CREATE INDEX idx_activities_legacy_communication_id ON public.activities(legacy_communication_id);
CREATE INDEX idx_activities_activity_date ON public.activities(activity_date DESC);

-- Add updated_at trigger
CREATE TRIGGER update_activities_updated_at
BEFORE UPDATE ON public.activities
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();