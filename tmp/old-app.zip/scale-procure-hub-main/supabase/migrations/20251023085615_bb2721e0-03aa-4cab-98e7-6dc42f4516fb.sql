-- Add new columns to communication_log for pipeline quotations
ALTER TABLE communication_log
ADD COLUMN IF NOT EXISTS city text,
ADD COLUMN IF NOT EXISTS location text,
ADD COLUMN IF NOT EXISTS quantity numeric;