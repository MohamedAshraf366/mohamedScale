-- Add status column to quarterly_tasks for tracking completion
ALTER TABLE public.quarterly_tasks 
ADD COLUMN status text NOT NULL DEFAULT 'active';

-- Add index for efficient filtering
CREATE INDEX idx_quarterly_tasks_status ON public.quarterly_tasks(status);