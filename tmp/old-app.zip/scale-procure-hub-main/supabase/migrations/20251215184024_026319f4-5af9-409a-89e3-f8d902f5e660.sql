-- Create feature_pipeline table
CREATE TABLE public.feature_pipeline (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  bucket TEXT NOT NULL CHECK (bucket IN ('Platform Features', 'Automations & Integrations')),
  title TEXT NOT NULL,
  description TEXT,
  priority TEXT NOT NULL DEFAULT 'Medium' CHECK (priority IN ('High', 'Medium', 'Low')),
  expected_date DATE,
  status TEXT NOT NULL DEFAULT 'Not Started' CHECK (status IN ('Not Started', 'In Progress', 'Completed')),
  display_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.feature_pipeline ENABLE ROW LEVEL SECURITY;

-- All authenticated users can view features
CREATE POLICY "All authenticated users can view features"
ON public.feature_pipeline
FOR SELECT
USING (true);

-- Only admins can insert features
CREATE POLICY "Admins can insert features"
ON public.feature_pipeline
FOR INSERT
WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role));

-- Only admins can update features
CREATE POLICY "Admins can update features"
ON public.feature_pipeline
FOR UPDATE
USING (check_user_role(auth.uid(), 'admin'::app_role));

-- Only admins can delete features
CREATE POLICY "Admins can delete features"
ON public.feature_pipeline
FOR DELETE
USING (check_user_role(auth.uid(), 'admin'::app_role));

-- Add trigger for updated_at
CREATE TRIGGER update_feature_pipeline_updated_at
BEFORE UPDATE ON public.feature_pipeline
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();