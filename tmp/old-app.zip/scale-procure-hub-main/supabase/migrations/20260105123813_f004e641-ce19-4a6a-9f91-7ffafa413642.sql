-- Add 'Done' and 'Cancelled' values to communication_status enum
ALTER TYPE communication_status ADD VALUE IF NOT EXISTS 'Done';
ALTER TYPE communication_status ADD VALUE IF NOT EXISTS 'Cancelled';