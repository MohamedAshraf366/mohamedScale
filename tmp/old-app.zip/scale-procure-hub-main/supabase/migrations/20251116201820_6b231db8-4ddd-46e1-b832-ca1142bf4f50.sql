-- Create follow_up_history table
CREATE TABLE public.follow_up_history (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  communication_log_id UUID NOT NULL REFERENCES public.communication_log(id) ON DELETE CASCADE,
  follow_up_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  user_id UUID NOT NULL,
  action TEXT,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.follow_up_history ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "All authenticated users can view follow-up history"
ON public.follow_up_history
FOR SELECT
USING (true);

CREATE POLICY "Admins and procurement can insert follow-up history"
ON public.follow_up_history
FOR INSERT
WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can update follow-up history"
ON public.follow_up_history
FOR UPDATE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and procurement can delete follow-up history"
ON public.follow_up_history
FOR DELETE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

-- Create function to update parent follow_up_date
CREATE OR REPLACE FUNCTION update_communication_follow_up_date()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE public.communication_log
  SET follow_up_date = NEW.follow_up_date::date
  WHERE id = NEW.communication_log_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to auto-update parent follow_up_date
CREATE TRIGGER trigger_update_communication_follow_up_date
AFTER INSERT ON public.follow_up_history
FOR EACH ROW
EXECUTE FUNCTION update_communication_follow_up_date();