-- Add is_general_quotation field to communication_log table
ALTER TABLE communication_log 
ADD COLUMN IF NOT EXISTS is_general_quotation BOOLEAN DEFAULT false;