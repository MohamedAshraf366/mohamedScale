-- Add deal fields to opportunities table
ALTER TABLE public.opportunities
ADD COLUMN IF NOT EXISTS is_deal boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS deal_id text,
ADD COLUMN IF NOT EXISTS is_locked boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS converted_to_deal_at timestamp with time zone;

-- Create function to generate deal ID
CREATE OR REPLACE FUNCTION public.generate_deal_id()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  next_number INTEGER;
  new_code TEXT;
BEGIN
  SELECT COALESCE(
    MAX(
      CAST(
        SUBSTRING(deal_id FROM 'DEAL-(\d+)') AS INTEGER
      )
    ), 0
  ) + 1 INTO next_number
  FROM opportunities
  WHERE deal_id ~ '^DEAL-\d+$';
  
  new_code := 'DEAL-' || LPAD(next_number::TEXT, 5, '0');
  RETURN new_code;
END;
$function$;

-- Create function to generate operations order number
CREATE OR REPLACE FUNCTION public.generate_order_number()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  next_number INTEGER;
  new_code TEXT;
BEGIN
  SELECT COALESCE(
    MAX(
      CAST(
        SUBSTRING(order_number FROM 'ORD-(\d+)') AS INTEGER
      )
    ), 0
  ) + 1 INTO next_number
  FROM operations_orders
  WHERE order_number ~ '^ORD-\d+$';
  
  new_code := 'ORD-' || LPAD(next_number::TEXT, 5, '0');
  RETURN new_code;
END;
$function$;

-- Create operations_orders table
CREATE TABLE public.operations_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number text NOT NULL,
  client_id uuid REFERENCES public.clients(id) NOT NULL,
  project_id uuid REFERENCES public.projects(id) NOT NULL,
  opportunity_id uuid REFERENCES public.opportunities(id) NOT NULL,
  deal_id text NOT NULL,
  status text NOT NULL DEFAULT 'DRAFT',
  notes text,
  created_by uuid,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Create operations_order_materials table
CREATE TABLE public.operations_order_materials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES public.operations_orders(id) ON DELETE CASCADE NOT NULL,
  material_name text NOT NULL,
  quantity numeric,
  expected_delivery_date date,
  pricing_type text,
  notes text,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Create system_tasks table for handover tasks
CREATE TABLE public.system_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_type text NOT NULL,
  title text NOT NULL,
  description text,
  related_entity_type text,
  related_entity_id uuid,
  assigned_to_role text,
  assigned_to_user uuid,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.operations_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.operations_order_materials ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_tasks ENABLE ROW LEVEL SECURITY;

-- RLS Policies for operations_orders
CREATE POLICY "All authenticated users can view operations orders"
ON public.operations_orders FOR SELECT
USING (true);

CREATE POLICY "Admins and operations can insert operations orders"
ON public.operations_orders FOR INSERT
WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'operations'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and operations can update operations orders"
ON public.operations_orders FOR UPDATE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'operations'::app_role));

CREATE POLICY "Admins can delete operations orders"
ON public.operations_orders FOR DELETE
USING (check_user_role(auth.uid(), 'admin'::app_role));

-- RLS Policies for operations_order_materials
CREATE POLICY "All authenticated users can view order materials"
ON public.operations_order_materials FOR SELECT
USING (true);

CREATE POLICY "Admins and operations can insert order materials"
ON public.operations_order_materials FOR INSERT
WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'operations'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and operations can update order materials"
ON public.operations_order_materials FOR UPDATE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'operations'::app_role));

CREATE POLICY "Admins and operations can delete order materials"
ON public.operations_order_materials FOR DELETE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'operations'::app_role));

-- RLS Policies for system_tasks
CREATE POLICY "All authenticated users can view system tasks"
ON public.system_tasks FOR SELECT
USING (true);

CREATE POLICY "Admins and procurement can insert system tasks"
ON public.system_tasks FOR INSERT
WITH CHECK (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'procurement_officer'::app_role));

CREATE POLICY "Admins and operations can update system tasks"
ON public.system_tasks FOR UPDATE
USING (check_user_role(auth.uid(), 'admin'::app_role) OR check_user_role(auth.uid(), 'operations'::app_role));

CREATE POLICY "Admins can delete system tasks"
ON public.system_tasks FOR DELETE
USING (check_user_role(auth.uid(), 'admin'::app_role));

-- Trigger for updated_at on operations_orders
CREATE TRIGGER update_operations_orders_updated_at
BEFORE UPDATE ON public.operations_orders
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Trigger for updated_at on system_tasks
CREATE TRIGGER update_system_tasks_updated_at
BEFORE UPDATE ON public.system_tasks
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();