-- Add unit_price column to operations_order_materials to store the price from Sales
ALTER TABLE public.operations_order_materials 
ADD COLUMN IF NOT EXISTS unit_price numeric DEFAULT NULL;