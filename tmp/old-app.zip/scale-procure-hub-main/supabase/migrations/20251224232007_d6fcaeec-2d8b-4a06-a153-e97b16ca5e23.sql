-- Add attachments column to supplier_issues table for photo storage
ALTER TABLE public.supplier_issues 
ADD COLUMN IF NOT EXISTS attachments text[] DEFAULT '{}';

-- Create storage bucket for issue attachments
INSERT INTO storage.buckets (id, name, public)
VALUES ('issue-attachments', 'issue-attachments', true)
ON CONFLICT (id) DO NOTHING;

-- Create storage policies for issue attachments
CREATE POLICY "Authenticated users can upload issue attachments"
ON storage.objects
FOR INSERT
WITH CHECK (bucket_id = 'issue-attachments' AND auth.role() = 'authenticated');

CREATE POLICY "Anyone can view issue attachments"
ON storage.objects
FOR SELECT
USING (bucket_id = 'issue-attachments');

CREATE POLICY "Authenticated users can delete their issue attachments"
ON storage.objects
FOR DELETE
USING (bucket_id = 'issue-attachments' AND auth.role() = 'authenticated');