-- Add objection_type column to communication_log
ALTER TABLE public.communication_log 
ADD COLUMN IF NOT EXISTS objection_type text;

-- Drop existing trigger and function
DROP TRIGGER IF EXISTS trigger_auto_create_followup ON public.communication_log;
DROP FUNCTION IF EXISTS public.auto_create_followup_for_communication();

-- Create updated trigger function with objection-based follow-up sequences
CREATE OR REPLACE FUNCTION public.auto_create_followup_for_communication()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  existing_followup_count INTEGER;
  followup_date TIMESTAMP WITH TIME ZONE;
  assigned_user_id UUID;
  base_date TIMESTAMP WITH TIME ZONE;
BEGIN
  -- Only proceed if interest_level is set to one of the valid values
  IF NEW.interest_level IS NULL OR NEW.interest_level NOT IN ('High', 'Medium', 'Low', 'Not interested') THEN
    RETURN NEW;
  END IF;

  -- Check for duplicate: if a follow-up with "Follow-up 1" already exists for this communication
  SELECT COUNT(*) INTO existing_followup_count
  FROM public.follow_up_history
  WHERE communication_log_id = NEW.id
    AND action ILIKE '%Follow-up 1%';

  -- If already exists, skip creation
  IF existing_followup_count > 0 THEN
    RETURN NEW;
  END IF;

  -- Calculate base date: communication_date or now()
  IF NEW.communication_date IS NOT NULL THEN
    base_date := NEW.communication_date;
  ELSE
    base_date := NOW();
  END IF;
  
  followup_date := base_date + INTERVAL '1 day';

  -- Determine the user to assign
  assigned_user_id := COALESCE(NEW.owner_id, '00000000-0000-0000-0000-000000000000'::UUID);

  -- Create Follow-up 1 for ALL interested levels (including Not interested)
  INSERT INTO public.follow_up_history (
    communication_log_id,
    follow_up_date,
    user_id,
    status_after,
    follow_up_type,
    action,
    notes,
    priority,
    reminder_enabled
  ) VALUES (
    NEW.id,
    followup_date,
    assigned_user_id,
    'Open',
    'General Follow-up',
    'Follow-up 1 – إرسال رسالة شكر والملف التعريفي',
    'Automatic follow-up created from Communication Tracker.',
    'Medium',
    true
  );

  -- If "Not interested", create additional follow-ups based on objection_type
  IF NEW.interest_level = 'Not interested' AND NEW.objection_type IS NOT NULL THEN
    
    -- Objection Type: Not Interested
    IF NEW.objection_type = 'Not Interested' THEN
      INSERT INTO public.follow_up_history (communication_log_id, follow_up_date, user_id, status_after, follow_up_type, action, notes, priority, reminder_enabled)
      VALUES 
        (NEW.id, followup_date + INTERVAL '1 day', assigned_user_id, 'Open', 'General Follow-up', 'Follow-up 2 – تمام، متى يناسب نتواصل معك مرة ثانية؟', 'Objection: Not Interested', 'Medium', true),
        (NEW.id, followup_date + INTERVAL '4 days', assigned_user_id, 'Open', 'General Follow-up', 'Follow-up 3 – هل يناسبك نرجع لك بتاريخ (….)؟', 'Objection: Not Interested', 'Medium', true),
        (NEW.id, followup_date + INTERVAL '11 days', assigned_user_id, 'Open', 'General Follow-up', 'Follow-up 4 – طيب، وش الوقت اللي تشوفه مناسب للمتابعة؟', 'Objection: Not Interested – Final Status: Cold Lead – Monitor Only', 'Medium', true);
    
    -- Objection Type: Price Too High
    ELSIF NEW.objection_type = 'Price Too High' THEN
      INSERT INTO public.follow_up_history (communication_log_id, follow_up_date, user_id, status_after, follow_up_type, action, notes, priority, reminder_enabled)
      VALUES 
        (NEW.id, followup_date + INTERVAL '1 day', assigned_user_id, 'Open', 'General Follow-up', 'Follow-up 2 – نوضح له ليش سعرنا يستاهل: جودة أعلى + توريد أسرع وأضمن.', 'Objection: Price Too High', 'Medium', true),
        (NEW.id, followup_date + INTERVAL '4 days', assigned_user_id, 'Open', 'General Follow-up', 'Follow-up 3 – نعرض عليه شروط دفع مريحة.', 'Objection: Price Too High', 'Medium', true),
        (NEW.id, followup_date + INTERVAL '11 days', assigned_user_id, 'Open', 'General Follow-up', 'Follow-up 4 – ممكن نعرض له كريديت.', 'Objection: Price Too High – Final Status: Price-Sensitive Lead', 'Medium', true);
    
    -- Objection Type: Specific Requirements Needed
    ELSIF NEW.objection_type = 'Specific Requirements Needed' THEN
      INSERT INTO public.follow_up_history (communication_log_id, follow_up_date, user_id, status_after, follow_up_type, action, notes, priority, reminder_enabled)
      VALUES 
        (NEW.id, followup_date + INTERVAL '1 day', assigned_user_id, 'Open', 'General Follow-up', 'Follow-up 2 – إرسال شهادات المطابقة + شرح المواصفات', 'Objection: Specific Requirements Needed', 'Medium', true),
        (NEW.id, followup_date + INTERVAL '4 days', assigned_user_id, 'Open', 'General Follow-up', 'Follow-up 3 – نسأله وش المواصفات اللي يبونها بالضبط', 'Objection: Specific Requirements Needed', 'Medium', true),
        (NEW.id, followup_date + INTERVAL '11 days', assigned_user_id, 'Open', 'General Follow-up', 'Follow-up 4 – طلب التواصل مع الفني المسؤول لاعتماد المورد', 'Objection: Specific Requirements Needed – Final Status: Pending Technical Approval', 'Medium', true);
    
    -- Objection Type: Payment Terms Issue
    ELSIF NEW.objection_type = 'Payment Terms Issue' THEN
      INSERT INTO public.follow_up_history (communication_log_id, follow_up_date, user_id, status_after, follow_up_type, action, notes, priority, reminder_enabled)
      VALUES 
        (NEW.id, followup_date + INTERVAL '1 day', assigned_user_id, 'Open', 'General Follow-up', 'Follow-up 2 – الدفع خلال 3–5 أيام طبيعي عندنا وما فيه أي تعقيد', 'Objection: Payment Terms Issue', 'Medium', true),
        (NEW.id, followup_date + INTERVAL '4 days', assigned_user_id, 'Open', 'General Follow-up', 'Follow-up 3 – الشروط ممكن تتحسن إذا زاد التعامل', 'Objection: Payment Terms Issue', 'Medium', true),
        (NEW.id, followup_date + INTERVAL '11 days', assigned_user_id, 'Open', 'General Follow-up', 'Follow-up 4 – شرح طريقة التوريد وكيف نفاوض ونضمن الجودة', 'Objection: Payment Terms Issue – Final Status: Payment Concern Lead', 'Medium', true);
    
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

-- Create the trigger on communication_log table
CREATE TRIGGER trigger_auto_create_followup
  AFTER INSERT ON public.communication_log
  FOR EACH ROW
  EXECUTE FUNCTION public.auto_create_followup_for_communication();