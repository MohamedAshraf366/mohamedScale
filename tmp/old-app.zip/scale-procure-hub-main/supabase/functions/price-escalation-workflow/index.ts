import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface EscalationRecord {
  id: string;
  material_id: string;
  supplier_id: string | null;
  escalation_phase: string;
  escalation_started_at: string | null;
  last_ai_message_at: string | null;
  ai_attempt_count: number;
  price_valid_until: string;
  current_price: number | null;
}

interface Material {
  id: string;
  name: string;
}

interface Supplier {
  id: string;
  name: string;
  phone: string | null;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { action, material_id, validity_tracker_id } = await req.json();

    console.log(`[Escalation Workflow] Action: ${action}, Material: ${material_id}, Tracker: ${validity_tracker_id}`);

    if (action === 'check_and_escalate') {
      // Process escalations for all materials with expiring/overdue prices
      const result = await processEscalations(supabase);
      return new Response(
        JSON.stringify({ success: true, ...result }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (action === 'manual_trigger_ai') {
      // Manually trigger AI outreach for a specific material
      if (!validity_tracker_id) {
        return new Response(
          JSON.stringify({ error: 'validity_tracker_id is required' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      const result = await triggerAIOutreach(supabase, validity_tracker_id);
      return new Response(
        JSON.stringify(result),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (action === 'officer_confirm') {
      // Officer confirms the price manually
      if (!validity_tracker_id) {
        return new Response(
          JSON.stringify({ error: 'validity_tracker_id is required' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      const result = await officerConfirmPrice(supabase, validity_tracker_id);
      return new Response(
        JSON.stringify(result),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (action === 'officer_close_no_response') {
      // Officer marks supplier as no response
      if (!validity_tracker_id) {
        return new Response(
          JSON.stringify({ error: 'validity_tracker_id is required' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      const result = await officerCloseNoResponse(supabase, validity_tracker_id);
      return new Response(
        JSON.stringify(result),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ error: 'Invalid action' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('[Escalation Workflow] Error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

async function processEscalations(supabase: any) {
  const now = new Date();
  const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  const threeDaysAgo = new Date(now.getTime() - 3 * 24 * 60 * 60 * 1000);

  let aiAttempt1Count = 0;
  let aiAttempt2Count = 0;
  let escalatedToOfficerCount = 0;

  // 1. Find materials with expiring/overdue validity that haven't started escalation
  const { data: pendingEscalations, error: pendingError } = await supabase
    .from('material_validity_tracker')
    .select('id, material_id, supplier_id, escalation_phase, price_valid_until, current_price')
    .eq('is_active', true)
    .eq('escalation_phase', 'none')
    .lte('price_valid_until', new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]); // Expiring within 30 days

  if (pendingError) {
    console.error('[Escalation] Error fetching pending escalations:', pendingError);
  } else if (pendingEscalations && pendingEscalations.length > 0) {
    console.log(`[Escalation] Found ${pendingEscalations.length} materials to start escalation`);
    
    for (const record of pendingEscalations) {
      // Start escalation - Day 1: AI Attempt 1
      await supabase
        .from('material_validity_tracker')
        .update({
          escalation_phase: 'ai_attempt_1',
          escalation_started_at: now.toISOString(),
          last_ai_message_at: now.toISOString(),
          ai_attempt_count: 1,
          updated_at: now.toISOString()
        })
        .eq('id', record.id);
      
      // Log the AI message (simulated)
      await logAIOutreach(supabase, record, 'Initial price confirmation request');
      aiAttempt1Count++;
    }
  }

  // 2. Check for materials in ai_attempt_1 for more than 3 days → escalate to ai_attempt_2
  const { data: attempt1Records, error: attempt1Error } = await supabase
    .from('material_validity_tracker')
    .select('id, material_id, supplier_id, escalation_phase, last_ai_message_at, current_price')
    .eq('is_active', true)
    .eq('escalation_phase', 'ai_attempt_1')
    .lt('last_ai_message_at', threeDaysAgo.toISOString());

  if (attempt1Error) {
    console.error('[Escalation] Error fetching ai_attempt_1 records:', attempt1Error);
  } else if (attempt1Records && attempt1Records.length > 0) {
    console.log(`[Escalation] Found ${attempt1Records.length} materials for AI Attempt 2`);
    
    for (const record of attempt1Records) {
      // Day 3: Send urgent follow-up
      await supabase
        .from('material_validity_tracker')
        .update({
          escalation_phase: 'ai_attempt_2',
          last_ai_message_at: now.toISOString(),
          ai_attempt_count: 2,
          updated_at: now.toISOString()
        })
        .eq('id', record.id);
      
      await logAIOutreach(supabase, record, 'URGENT: Follow-up price confirmation request');
      aiAttempt2Count++;
    }
  }

  // 3. Check for materials in ai_attempt_2 for more than 1 day → escalate to pending_officer
  const { data: attempt2Records, error: attempt2Error } = await supabase
    .from('material_validity_tracker')
    .select('id, material_id, supplier_id, escalation_phase, last_ai_message_at, current_price')
    .eq('is_active', true)
    .eq('escalation_phase', 'ai_attempt_2')
    .lt('last_ai_message_at', oneDayAgo.toISOString());

  if (attempt2Error) {
    console.error('[Escalation] Error fetching ai_attempt_2 records:', attempt2Error);
  } else if (attempt2Records && attempt2Records.length > 0) {
    console.log(`[Escalation] Found ${attempt2Records.length} materials for officer escalation`);
    
    for (const record of attempt2Records) {
      // Day 4: Escalate to Supply Officer
      await supabase
        .from('material_validity_tracker')
        .update({
          escalation_phase: 'pending_officer',
          officer_assigned_at: now.toISOString(),
          updated_at: now.toISOString()
        })
        .eq('id', record.id);
      
      // Create escalation task
      await createEscalationTask(supabase, record);
      escalatedToOfficerCount++;
    }
  }

  return {
    aiAttempt1Count,
    aiAttempt2Count,
    escalatedToOfficerCount,
    processedAt: now.toISOString()
  };
}

async function triggerAIOutreach(supabase: any, validityTrackerId: string) {
  const now = new Date();

  // Get the validity tracker record
  const { data: record, error } = await supabase
    .from('material_validity_tracker')
    .select('id, material_id, supplier_id, escalation_phase, ai_attempt_count, current_price')
    .eq('id', validityTrackerId)
    .single();

  if (error || !record) {
    console.error('[Escalation] Record not found:', error);
    return { success: false, error: 'Record not found' };
  }

  const newAttemptCount = (record.ai_attempt_count || 0) + 1;
  const newPhase = newAttemptCount === 1 ? 'ai_attempt_1' : 'ai_attempt_2';

  // Update the record
  await supabase
    .from('material_validity_tracker')
    .update({
      escalation_phase: newPhase,
      escalation_started_at: record.escalation_started_at || now.toISOString(),
      last_ai_message_at: now.toISOString(),
      ai_attempt_count: newAttemptCount,
      updated_at: now.toISOString()
    })
    .eq('id', validityTrackerId);

  // Log the outreach
  const message = newAttemptCount === 1 
    ? 'Manual trigger: Initial price confirmation request' 
    : 'Manual trigger: Urgent follow-up price confirmation';
  
  await logAIOutreach(supabase, record, message);

  console.log(`[Escalation] Manual AI outreach triggered for ${validityTrackerId}, attempt ${newAttemptCount}`);

  return { 
    success: true, 
    phase: newPhase, 
    attemptCount: newAttemptCount 
  };
}

async function officerConfirmPrice(supabase: any, validityTrackerId: string) {
  const now = new Date();

  const { error } = await supabase
    .from('material_validity_tracker')
    .update({
      escalation_phase: 'officer_confirmed',
      confirmation_source: 'officer_confirmed',
      last_confirmed_at: now.toISOString(),
      price_valid_until: new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      updated_at: now.toISOString()
    })
    .eq('id', validityTrackerId);

  if (error) {
    console.error('[Escalation] Error confirming price:', error);
    return { success: false, error: error.message };
  }

  // Complete any related escalation task
  await supabase
    .from('escalation_tasks')
    .update({
      status: 'completed',
      completed_at: now.toISOString(),
      notes: 'Price confirmed by officer'
    })
    .eq('validity_tracker_id', validityTrackerId)
    .eq('status', 'pending');

  console.log(`[Escalation] Price confirmed by officer for ${validityTrackerId}`);

  return { success: true, phase: 'officer_confirmed' };
}

async function officerCloseNoResponse(supabase: any, validityTrackerId: string) {
  const now = new Date();

  const { error } = await supabase
    .from('material_validity_tracker')
    .update({
      escalation_phase: 'no_response_closed',
      updated_at: now.toISOString()
    })
    .eq('id', validityTrackerId);

  if (error) {
    console.error('[Escalation] Error closing record:', error);
    return { success: false, error: error.message };
  }

  // Complete any related escalation task
  await supabase
    .from('escalation_tasks')
    .update({
      status: 'completed',
      completed_at: now.toISOString(),
      notes: 'Closed - No response from supplier'
    })
    .eq('validity_tracker_id', validityTrackerId)
    .eq('status', 'pending');

  console.log(`[Escalation] Closed no response for ${validityTrackerId}`);

  return { success: true, phase: 'no_response_closed' };
}

async function logAIOutreach(supabase: any, record: any, message: string) {
  // Get material and supplier names for logging
  const { data: material } = await supabase
    .from('materials')
    .select('name')
    .eq('id', record.material_id)
    .single();

  const { data: supplier } = record.supplier_id 
    ? await supabase
        .from('suppliers')
        .select('name, phone')
        .eq('id', record.supplier_id)
        .single()
    : { data: null };

  console.log(`[AI Outreach] ${message}`);
  console.log(`  Material: ${material?.name || record.material_id}`);
  console.log(`  Supplier: ${supplier?.name || 'N/A'}`);
  console.log(`  Phone: ${supplier?.phone || 'N/A'}`);
  
  // In a real implementation, this would send a WhatsApp message
  // For now, we just log the intent
}

async function createEscalationTask(supabase: any, record: any) {
  const { data: material } = await supabase
    .from('materials')
    .select('name')
    .eq('id', record.material_id)
    .single();

  const { data: supplier } = record.supplier_id 
    ? await supabase
        .from('suppliers')
        .select('name')
        .eq('id', record.supplier_id)
        .single()
    : { data: null };

  const taskNotes = `Final Contact Required: ${material?.name || 'Material'} - ${supplier?.name || 'Unknown Supplier'}. AI outreach received no response after 2 attempts.`;

  const { error } = await supabase
    .from('escalation_tasks')
    .insert({
      material_id: record.material_id,
      supplier_id: record.supplier_id,
      validity_tracker_id: record.id,
      task_type: 'final_contact',
      status: 'pending',
      notes: taskNotes
    });

  if (error) {
    console.error('[Escalation] Error creating task:', error);
  } else {
    console.log(`[Escalation] Created escalation task for ${record.material_id}`);
  }
}
