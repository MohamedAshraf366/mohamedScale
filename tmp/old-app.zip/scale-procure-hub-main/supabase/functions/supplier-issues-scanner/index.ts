import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface SupplierIssueAggregate {
  supplier_id: string;
  supplier_name: string;
  critical_count: number;
  major_count: number;
  total_severe_issues: number;
  issues: Array<{
    id: string;
    issue_type: string;
    severity: string;
    description: string | null;
    created_at: string;
    material_name: string | null;
  }>;
  first_material_id: string | null;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  console.log('🔍 Starting supplier issues scan (Three Strikes Check)...');

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Calculate 30-day rolling window
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const windowStart = thirtyDaysAgo.toISOString();

    console.log(`📅 Checking issues from ${windowStart} onwards...`);

    // Fetch all Critical and Major issues in the 30-day window that are not resolved
    const { data: recentIssues, error: issuesError } = await supabase
      .from('supplier_issues')
      .select(`
        id,
        supplier_id,
        material_id,
        issue_type,
        severity,
        description,
        created_at,
        status,
        supplier:suppliers(id, name),
        material:materials(id, name)
      `)
      .gte('created_at', windowStart)
      .in('severity', ['critical', 'major'])
      .neq('status', 'resolved');

    if (issuesError) {
      console.error('❌ Error fetching issues:', issuesError);
      throw issuesError;
    }

    console.log(`📊 Found ${recentIssues?.length || 0} Critical/Major issues in 30-day window`);

    if (!recentIssues || recentIssues.length === 0) {
      console.log('✅ No severe issues found. Scan complete.');
      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'No severe issues found',
          suppliersTriggered: 0 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Aggregate issues by supplier
    const supplierAggregates = new Map<string, SupplierIssueAggregate>();

    for (const issue of recentIssues) {
      const supplierId = issue.supplier_id;
      const existing = supplierAggregates.get(supplierId);
      
      // Handle joined data properly (can be array or object)
      const supplierData = Array.isArray(issue.supplier) ? issue.supplier[0] : issue.supplier;
      const materialData = Array.isArray(issue.material) ? issue.material[0] : issue.material;

      const issueData = {
        id: issue.id,
        issue_type: issue.issue_type,
        severity: issue.severity,
        description: issue.description,
        created_at: issue.created_at,
        material_name: materialData?.name || null,
      };

      if (existing) {
        if (issue.severity === 'critical') existing.critical_count++;
        if (issue.severity === 'major') existing.major_count++;
        existing.total_severe_issues++;
        existing.issues.push(issueData);
        if (!existing.first_material_id && issue.material_id) {
          existing.first_material_id = issue.material_id;
        }
      } else {
        supplierAggregates.set(supplierId, {
          supplier_id: supplierId,
          supplier_name: supplierData?.name || 'Unknown',
          critical_count: issue.severity === 'critical' ? 1 : 0,
          major_count: issue.severity === 'major' ? 1 : 0,
          total_severe_issues: 1,
          issues: [issueData],
          first_material_id: issue.material_id || null,
        });
      }
    }

    console.log(`📋 Aggregated issues for ${supplierAggregates.size} suppliers`);

    // Filter suppliers with 3+ severe issues
    const triggeredSuppliers = Array.from(supplierAggregates.values())
      .filter(s => s.total_severe_issues >= 3);

    console.log(`⚠️ ${triggeredSuppliers.length} suppliers have 3+ severe issues`);

    if (triggeredSuppliers.length === 0) {
      console.log('✅ No suppliers triggered the three strikes rule. Scan complete.');
      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'No suppliers triggered',
          suppliersTriggered: 0 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check for existing active renegotiations for these suppliers
    const supplierIds = triggeredSuppliers.map(s => s.supplier_id);
    
    const { data: existingRenegotiations, error: renegError } = await supabase
      .from('material_renegotiations')
      .select('supplier_id')
      .in('supplier_id', supplierIds)
      .not('approval_status', 'eq', 'rejected')
      .not('renegotiation_status', 'in', '("completed","cancelled")');

    if (renegError) {
      console.error('❌ Error checking existing renegotiations:', renegError);
      throw renegError;
    }

    const suppliersWithActiveReneg = new Set(existingRenegotiations?.map(r => r.supplier_id) || []);
    
    // Filter out suppliers that already have active renegotiations
    const suppliersNeedingReneg = triggeredSuppliers.filter(
      s => !suppliersWithActiveReneg.has(s.supplier_id)
    );

    console.log(`🎯 ${suppliersNeedingReneg.length} suppliers need new renegotiation requests`);

    const createdRenegotiations: string[] = [];

    for (const supplier of suppliersNeedingReneg) {
      // Build issue summary for trigger reason
      const issueSummary = supplier.issues
        .slice(0, 5) // Limit to 5 most recent
        .map(i => `• ${i.severity.toUpperCase()}: ${i.issue_type}${i.material_name ? ` (${i.material_name})` : ''}${i.description ? ` - ${i.description.substring(0, 100)}` : ''}`)
        .join('\n');

      const triggerReason = `🚨 THREE STRIKES AUTO-TRIGGER (30-day rolling window)

Supplier: ${supplier.supplier_name}
Total Severe Issues: ${supplier.total_severe_issues}
  - Critical: ${supplier.critical_count}
  - Major: ${supplier.major_count}

Recent Issues:
${issueSummary}

This renegotiation was automatically created due to accumulated supplier performance issues.`;

      // Get a material ID for the renegotiation (required field)
      let materialId = supplier.first_material_id;

      // If no material from issues, try to get one from supplier's materials
      if (!materialId) {
        const { data: supplierMaterials } = await supabase
          .from('supplier_materials')
          .select('material_id')
          .eq('supplier_id', supplier.supplier_id)
          .limit(1);

        if (supplierMaterials && supplierMaterials.length > 0) {
          materialId = supplierMaterials[0].material_id;
        }
      }

      // If still no material, try alt suppliers
      if (!materialId) {
        const { data: altSuppliers } = await supabase
          .from('material_alt_suppliers')
          .select('material_id')
          .eq('supplier_id', supplier.supplier_id)
          .limit(1);

        if (altSuppliers && altSuppliers.length > 0) {
          materialId = altSuppliers[0].material_id;
        }
      }

      // Last resort: get any material
      if (!materialId) {
        const { data: anyMaterial } = await supabase
          .from('materials')
          .select('id')
          .limit(1);

        if (anyMaterial && anyMaterial.length > 0) {
          materialId = anyMaterial[0].id;
        }
      }

      if (!materialId) {
        console.warn(`⚠️ Could not find a material for supplier ${supplier.supplier_name}, skipping...`);
        continue;
      }

      // Create the renegotiation request
      const { data: newReneg, error: createError } = await supabase
        .from('material_renegotiations')
        .insert({
          material_id: materialId,
          supplier_id: supplier.supplier_id,
          approval_status: 'pending_supply_head',
          supply_head_notes: triggerReason,
          renegotiation_status: 'pending',
        })
        .select('id')
        .single();

      if (createError) {
        console.error(`❌ Failed to create renegotiation for ${supplier.supplier_name}:`, createError);
        continue;
      }

      console.log(`✅ Created renegotiation ${newReneg.id} for supplier: ${supplier.supplier_name}`);
      createdRenegotiations.push(newReneg.id);

      // Update the supplier's at_risk status
      await supabase
        .from('suppliers')
        .update({
          is_at_risk: true,
          at_risk_since: new Date().toISOString(),
        })
        .eq('id', supplier.supplier_id);

      // Update the issues to link them to the renegotiation
      const issueIds = supplier.issues.map(i => i.id);
      await supabase
        .from('supplier_issues')
        .update({
          status: 'escalated_to_renegotiation',
          linked_renegotiation_id: newReneg.id,
          escalation_date: new Date().toISOString(),
        })
        .in('id', issueIds);
    }

    console.log(`🎉 Scan complete! Created ${createdRenegotiations.length} renegotiation requests`);

    return new Response(
      JSON.stringify({
        success: true,
        message: `Created ${createdRenegotiations.length} renegotiation requests`,
        suppliersTriggered: createdRenegotiations.length,
        renegotiationIds: createdRenegotiations,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('❌ Scanner error:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: errorMessage 
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});